//go:build !windows

package main

import (
	"errors"
	"os/exec"
)

func platformHiddenCommand(name string, args ...string) *exec.Cmd { return exec.Command(name, args...) }
func applyHiddenWindow(cmd *exec.Cmd)                             {}
func acquireSingleInstance() (func(), bool, error)                { return func() {}, false, nil }
func showError(title, text string)                                {}
func showInfo(title, text string)                                 {}
func runNativeTray(app *App) error                                { return errors.New("Windows only") }
func requestAppExit()                                             {}

func notifyModeChanged(mode int) {}

package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestValidateDeviceSerial(t *testing.T) {
	for _, v := range []string{"", "emulator-5554", "127.0.0.1:5555", "USB123"} {
		if err := validDeviceSerial(v); err != nil {
			t.Fatalf("%s: %v", v, err)
		}
	}
	for _, v := range []string{"bad serial", "bad\nserial"} {
		if validDeviceSerial(v) == nil {
			t.Fatalf("expected invalid: %q", v)
		}
	}
}
func TestCoordinates(t *testing.T) {
	if validCoordinate(0, 0) {
		t.Fatal("zero coordinate must be unset")
	}
	if !validCoordinate(0, 100) {
		t.Fatal("edge coordinate should be allowed")
	}
}

func TestConfigSaveReplacesExistingFile(t *testing.T) {
	dir := t.TempDir()
	s := &ConfigStore{path: filepath.Join(dir, "config.json"), data: Config{Version: 3, DeviceSerial: "emulator-5554", ActiveMode: 1, Modes: make([]TapMode, 3)}}
	if err := os.WriteFile(s.path, []byte("old"), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := s.saveLocked(); err != nil {
		t.Fatal(err)
	}
	raw, err := os.ReadFile(s.path)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(raw), "emulator-5554") {
		t.Fatalf("unexpected config: %s", raw)
	}
}
func TestThreeModesAndActiveMode(t *testing.T) {
	dir := t.TempDir()
	s := &ConfigStore{path: filepath.Join(dir, "config.json"), data: defaultConfig()}
	cfg := defaultConfig()
	cfg.DeviceSerial = "emulator-5554"
	cfg.ActiveMode = 3
	cfg.Modes[2] = TapMode{MinusX: 10, MinusY: 20, PlusX: 30, PlusY: 40}
	got, err := s.Update(cfg)
	if err != nil {
		t.Fatal(err)
	}
	if got.ActiveMode != 3 || got.CurrentMode().PlusY != 40 || len(got.Modes) != 3 {
		t.Fatalf("unexpected config: %#v", got)
	}
	if _, err := s.SetActiveMode(2); err != nil {
		t.Fatal(err)
	}
	if s.Get().ActiveMode != 2 {
		t.Fatal("mode did not switch")
	}
}
func TestLegacyWirelessConfigMigratesCoordinatesAndDropsAddress(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("APPDATA", dir)
	appDir := filepath.Join(dir, "QAA-ADB-Tap")
	if err := os.MkdirAll(appDir, 0o755); err != nil {
		t.Fatal(err)
	}
	legacy := `{"version":1,"address":"127.0.0.1:5555","minusX":11,"minusY":22,"plusX":33,"plusY":44}`
	if err := os.WriteFile(filepath.Join(appDir, "config.json"), []byte(legacy), 0o600); err != nil {
		t.Fatal(err)
	}
	s, err := newConfigStore()
	if err != nil {
		t.Fatal(err)
	}
	cfg := s.Get()
	if cfg.Version != 3 || cfg.ActiveMode != 1 || cfg.DeviceSerial != "" || cfg.Modes[0].MinusX != 11 || cfg.Modes[0].PlusY != 44 {
		t.Fatalf("migration failed: %#v", cfg)
	}
}

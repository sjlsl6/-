package main

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

type tapRequest struct {
	x, y  int
	label string
}

type ADBDevice struct {
	Serial  string `json:"serial"`
	State   string `json:"state"`
	Details string `json:"details"`
}

type ADBManager struct {
	status     *StatusStore
	mu         sync.Mutex
	writeMu    sync.Mutex
	connectMu  sync.Mutex
	adbPath    string
	serial     string
	shell      *exec.Cmd
	stdin      io.WriteCloser
	stdout     io.ReadCloser
	stopping   bool
	requests   chan tapRequest
	stopWorker chan struct{}
	workerDone chan struct{}
}

func newADBManager(status *StatusStore) *ADBManager {
	a := &ADBManager{status: status, requests: make(chan tapRequest, 2), stopWorker: make(chan struct{}), workerDone: make(chan struct{})}
	go a.worker()
	return a
}

func executableDir() (string, error) {
	exe, err := os.Executable()
	if err != nil {
		return "", err
	}
	return filepath.Dir(exe), nil
}

func (a *ADBManager) findADB() (string, error) {
	dir, err := executableDir()
	if err != nil {
		return "", err
	}
	// 优先使用程序旁边的 ADB；其次使用 PATH 中用户已经在用的 ADB，
	// 这样雷电模拟器/USB 真机已经建立的 adb server 会尽量原样复用。
	candidates := []string{filepath.Join(dir, "platform-tools", "adb.exe"), filepath.Join(dir, "adb.exe")}
	if p, err := exec.LookPath("adb.exe"); err == nil {
		candidates = append(candidates, p)
	}
	if cfgDir, cfgErr := configDirectory(); cfgErr == nil {
		candidates = append(candidates, filepath.Join(cfgDir, "platform-tools", "adb.exe"))
	}
	if appData := strings.TrimSpace(os.Getenv("APPDATA")); appData != "" {
		candidates = append(candidates,
			filepath.Join(appData, "QAA-AirType-Voice-v2", "platform-tools", "adb.exe"),
			filepath.Join(appData, "QAA-AirType-Keyboard-v23", "platform-tools", "adb.exe"),
		)
	}
	seen := map[string]bool{}
	for _, p := range candidates {
		key := strings.ToLower(filepath.Clean(p))
		if seen[key] {
			continue
		}
		seen[key] = true
		if validADBExecutable(p) {
			return p, nil
		}
	}
	return "", errors.New("未找到可用的 ADB，请在设置页点击“一次性准备 ADB”")
}

func validADBExecutable(path string) bool {
	st, err := os.Stat(path)
	if err != nil || st.IsDir() {
		return false
	}
	dir := filepath.Dir(path)
	for _, name := range []string{"AdbWinApi.dll", "AdbWinUsbApi.dll"} {
		if info, err := os.Stat(filepath.Join(dir, name)); err != nil || info.IsDir() {
			return false
		}
	}
	return true
}

func hiddenCommand(name string, args ...string) *exec.Cmd {
	return platformHiddenCommand(name, args...)
}

func runOutput(timeout time.Duration, name string, args ...string) (string, int, error) {
	return runOutputContext(context.Background(), timeout, name, args...)
}

func runOutputContext(parent context.Context, timeout time.Duration, name string, args ...string) (string, int, error) {
	ctx, cancel := context.WithTimeout(parent, timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, name, args...)
	applyHiddenWindow(cmd)
	raw, err := cmd.CombinedOutput()
	out := strings.TrimSpace(string(raw))
	if parentErr := parent.Err(); parentErr != nil {
		return out, -1, parentErr
	}
	if ctx.Err() == context.DeadlineExceeded {
		return out, -1, errors.New("操作超时")
	}
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			return out, ee.ExitCode(), err
		}
		return out, -1, err
	}
	return out, 0, nil
}

func outputLooksFailed(out string) bool {
	v := strings.ToLower(out)
	for _, word := range []string{"failed", "cannot", "unable", "offline", "unauthorized", "refused", "timed out", "no route"} {
		if strings.Contains(v, word) {
			return true
		}
	}
	return false
}

func parseADBDevices(output string) []ADBDevice {
	devices := make([]ADBDevice, 0)
	for _, rawLine := range strings.Split(strings.ReplaceAll(output, "\r\n", "\n"), "\n") {
		line := strings.TrimSpace(rawLine)
		if line == "" || strings.HasPrefix(line, "List of devices attached") || strings.HasPrefix(line, "*") {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 2 {
			continue
		}
		serial, state := fields[0], fields[1]
		if serial == "" || strings.Contains(serial, ":") && serial == "adb" {
			continue
		}
		details := ""
		if len(fields) > 2 {
			details = strings.Join(fields[2:], " ")
		}
		devices = append(devices, ADBDevice{Serial: serial, State: state, Details: details})
	}
	sort.SliceStable(devices, func(i, j int) bool {
		if devices[i].State == devices[j].State {
			return devices[i].Serial < devices[j].Serial
		}
		return devices[i].State == "device"
	})
	return devices
}

func (a *ADBManager) ListDevices() ([]ADBDevice, error) {
	adb, err := a.findADB()
	if err != nil {
		return nil, err
	}
	out, rc, runErr := runOutput(8*time.Second, adb, "devices", "-l")
	if runErr != nil || rc != 0 {
		if out == "" && runErr != nil {
			out = runErr.Error()
		}
		return nil, fmt.Errorf("读取 ADB 设备失败：%s", out)
	}
	return parseADBDevices(out), nil
}

func chooseADBDevice(devices []ADBDevice, preferred string) (string, error) {
	preferred = strings.TrimSpace(preferred)
	var ready []ADBDevice
	var blocked []ADBDevice
	for _, d := range devices {
		if d.State == "device" {
			ready = append(ready, d)
			if preferred != "" && d.Serial == preferred {
				return d.Serial, nil
			}
		} else {
			blocked = append(blocked, d)
		}
	}
	if len(ready) == 1 {
		return ready[0].Serial, nil
	}
	if len(ready) > 1 {
		names := make([]string, 0, len(ready))
		for _, d := range ready {
			names = append(names, d.Serial)
		}
		if preferred != "" {
			return "", fmt.Errorf("已保存设备 %s 当前不可用；检测到多个可用设备，请在设置页选择：%s", preferred, strings.Join(names, "、"))
		}
		return "", fmt.Errorf("检测到多个可用 ADB 设备，请在设置页选择一个：%s", strings.Join(names, "、"))
	}
	if len(blocked) > 0 {
		parts := make([]string, 0, len(blocked))
		for _, d := range blocked {
			parts = append(parts, fmt.Sprintf("%s(%s)", d.Serial, d.State))
		}
		return "", fmt.Errorf("未发现可用设备；当前设备状态：%s", strings.Join(parts, "、"))
	}
	return "", errors.New("未发现 ADB 设备。请先让雷电模拟器或 USB 手机出现在 adb devices 列表中")
}

// ConnectDirect attaches QAA to a device that is already visible in `adb devices`.
// It deliberately does not run `adb connect`, pair, scan mDNS, or alter the device transport.
func (a *ADBManager) ConnectDirect(preferredSerial string) (string, error) {
	a.connectMu.Lock()
	defer a.connectMu.Unlock()

	adb, err := a.findADB()
	if err != nil {
		return "", err
	}
	a.disconnectLocked()

	out, rc, runErr := runOutput(8*time.Second, adb, "devices", "-l")
	if runErr != nil || rc != 0 {
		if out == "" && runErr != nil {
			out = runErr.Error()
		}
		return "", fmt.Errorf("读取 ADB 设备失败：%s", out)
	}
	serial, err := chooseADBDevice(parseADBDevices(out), preferredSerial)
	if err != nil {
		return "", err
	}
	state, rc, runErr := runOutput(6*time.Second, adb, "-s", serial, "get-state")
	if runErr != nil || rc != 0 || strings.TrimSpace(state) != "device" {
		return "", fmt.Errorf("设备 %s 当前不可用：%s", serial, strings.TrimSpace(state))
	}
	if err := a.startShell(adb, serial); err != nil {
		return "", err
	}
	a.status.Connection(true, serial)
	a.status.Action("ADB 设备已连接；数字小键盘 - 和 + 已就绪")
	return serial, nil
}

func (a *ADBManager) startShell(adb, serial string) error {
	cmd := hiddenCommand(adb, "-s", serial, "shell")
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return err
	}
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		_ = stdin.Close()
		return err
	}
	cmd.Stderr = cmd.Stdout
	if err := cmd.Start(); err != nil {
		_ = stdin.Close()
		_ = stdout.Close()
		return fmt.Errorf("常驻 ADB Shell 启动失败：%w", err)
	}

	lines := make(chan string, 64)
	go func() {
		scanner := bufio.NewScanner(stdout)
		buf := make([]byte, 0, 64*1024)
		scanner.Buffer(buf, 1024*1024)
		for scanner.Scan() {
			select {
			case lines <- strings.TrimSpace(scanner.Text()):
			default:
			}
		}
		close(lines)
		_ = cmd.Wait()
		a.mu.Lock()
		current := a.shell == cmd
		if current {
			a.shell = nil
			a.stdin = nil
			a.stdout = nil
			a.serial = ""
		}
		stopping := a.stopping
		a.mu.Unlock()
		if current && !stopping {
			a.status.Connection(false, "")
			a.status.Error("常驻 ADB Shell 已断开，请重新检测并连接设备")
		}
	}()

	readyToken := fmt.Sprintf("__QAA_READY_%d__", time.Now().UnixNano())
	if _, err := io.WriteString(stdin, "echo "+readyToken+"\n"); err != nil {
		_ = cmd.Process.Kill()
		return err
	}
	if err := waitToken(lines, readyToken, 5*time.Second); err != nil {
		_ = cmd.Process.Kill()
		return errors.New("ADB Shell 未能完成准备，请重新连接")
	}
	warmToken := fmt.Sprintf("__QAA_WARM_%d__", time.Now().UnixNano())
	if _, err := io.WriteString(stdin, "input --help >/dev/null 2>&1; echo "+warmToken+"\n"); err != nil {
		_ = cmd.Process.Kill()
		return err
	}
	if err := waitToken(lines, warmToken, 6*time.Second); err != nil {
		_ = cmd.Process.Kill()
		return errors.New("设备点击命令预热失败，请重新连接")
	}

	a.mu.Lock()
	a.stopping = false
	a.adbPath = adb
	a.serial = serial
	a.shell = cmd
	a.stdin = stdin
	a.stdout = stdout
	a.mu.Unlock()
	return nil
}

func waitToken(lines <-chan string, token string, timeout time.Duration) error {
	timer := time.NewTimer(timeout)
	defer timer.Stop()
	for {
		select {
		case line, ok := <-lines:
			if !ok {
				return io.EOF
			}
			if line == token {
				return nil
			}
		case <-timer.C:
			return context.DeadlineExceeded
		}
	}
}

func (a *ADBManager) Trigger(x, y int, label string) error {
	if !validCoordinate(x, y) {
		return fmt.Errorf("%s坐标尚未设置", label)
	}
	a.mu.Lock()
	connected := a.shell != nil && a.stdin != nil && a.shell.ProcessState == nil
	a.mu.Unlock()
	if !connected {
		return errors.New("ADB 设备尚未连接，请先点击“检测并连接设备”")
	}
	req := tapRequest{x: x, y: y, label: label}
	select {
	case a.requests <- req:
		return nil
	default:
		return errors.New("上一条点击仍在发送，本次按键已丢弃，未形成积压")
	}
}

func (a *ADBManager) worker() {
	defer close(a.workerDone)
	for {
		select {
		case req := <-a.requests:
			a.status.SetBusy(true)
			err := a.writeTap(req)
			a.status.SetBusy(false)
			if err != nil {
				a.status.Error(err.Error())
			} else {
				a.status.Action(fmt.Sprintf("已发送%s点击：(%d, %d)", req.label, req.x, req.y))
			}
		case <-a.stopWorker:
			return
		}
	}
}

func (a *ADBManager) writeTap(req tapRequest) error {
	a.writeMu.Lock()
	defer a.writeMu.Unlock()
	a.mu.Lock()
	cmd, stdin := a.shell, a.stdin
	connected := cmd != nil && stdin != nil && cmd.ProcessState == nil
	a.mu.Unlock()
	if !connected {
		return errors.New("ADB 点击通道不可用，请重新检测并连接设备")
	}
	_, err := io.WriteString(stdin, fmt.Sprintf("input tap %d %d\n", req.x, req.y))
	if err == nil {
		return nil
	}
	a.mu.Lock()
	if a.shell == cmd && a.stdin == stdin {
		a.shell = nil
		a.stdin = nil
		a.stdout = nil
		a.serial = ""
	}
	a.mu.Unlock()
	a.status.Connection(false, "")
	return errors.New("ADB 点击通道已断开，请重新检测并连接设备")
}

func (a *ADBManager) Disconnect() {
	a.connectMu.Lock()
	defer a.connectMu.Unlock()
	a.disconnectLocked()
	a.status.Action("已断开 QAA 点击通道；不会断开模拟器或 USB 的 ADB 设备连接")
}

func (a *ADBManager) disconnectLocked() {
	a.mu.Lock()
	a.stopping = true
	cmd, stdin, stdout := a.shell, a.stdin, a.stdout
	a.shell = nil
	a.stdin = nil
	a.stdout = nil
	a.serial = ""
	a.mu.Unlock()
	if stdin != nil {
		_ = stdin.Close()
	}
	if stdout != nil {
		_ = stdout.Close()
	}
	if cmd != nil && cmd.Process != nil {
		_ = cmd.Process.Kill()
	}
	for {
		select {
		case <-a.requests:
		default:
			goto drained
		}
	}
drained:
	a.status.Connection(false, "")
	a.mu.Lock()
	a.stopping = false
	a.mu.Unlock()
}

func (a *ADBManager) Stop() {
	a.connectMu.Lock()
	a.disconnectLocked()
	a.connectMu.Unlock()
	select {
	case <-a.stopWorker:
	default:
		close(a.stopWorker)
	}
	select {
	case <-a.workerDone:
	case <-time.After(2 * time.Second):
	}
}

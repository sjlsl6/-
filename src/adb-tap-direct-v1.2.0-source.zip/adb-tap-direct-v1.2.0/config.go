package main

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

type TapMode struct {
	MinusX int `json:"minusX"`
	MinusY int `json:"minusY"`
	PlusX  int `json:"plusX"`
	PlusY  int `json:"plusY"`
}

type Config struct {
	Version      int       `json:"version"`
	DeviceSerial string    `json:"deviceSerial"`
	ActiveMode   int       `json:"activeMode"`
	Modes        []TapMode `json:"modes"`
}

type legacyConfig struct {
	Version int `json:"version"`
	MinusX  int `json:"minusX"`
	MinusY  int `json:"minusY"`
	PlusX   int `json:"plusX"`
	PlusY   int `json:"plusY"`
}

type ConfigStore struct {
	mu   sync.RWMutex
	path string
	data Config
}

func configDirectory() (string, error) {
	appData := strings.TrimSpace(os.Getenv("APPDATA"))
	if appData == "" {
		return "", errors.New("无法读取 Windows APPDATA 目录")
	}
	dir := filepath.Join(appData, "QAA-ADB-Tap")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	return dir, nil
}

func defaultConfig() Config { return Config{Version: 3, ActiveMode: 1, Modes: make([]TapMode, 3)} }

func newConfigStore() (*ConfigStore, error) {
	dir, err := configDirectory()
	if err != nil {
		return nil, err
	}
	s := &ConfigStore{path: filepath.Join(dir, "config.json"), data: defaultConfig()}
	if raw, err := os.ReadFile(s.path); err == nil {
		var next Config
		if json.Unmarshal(raw, &next) == nil && len(next.Modes) > 0 {
			// v1/v2 中的无线 Address 字段会被 json.Unmarshal 自动忽略；坐标继续保留。
			s.data = next
		} else {
			var old legacyConfig
			if json.Unmarshal(raw, &old) == nil {
				s.data.Modes[0] = TapMode{MinusX: old.MinusX, MinusY: old.MinusY, PlusX: old.PlusX, PlusY: old.PlusY}
			}
		}
	}
	s.normalizeLocked()
	if err := s.saveLocked(); err != nil {
		return nil, err
	}
	return s, nil
}

func normalizeMode(m TapMode) TapMode {
	if m.MinusX < 0 {
		m.MinusX = 0
	}
	if m.MinusY < 0 {
		m.MinusY = 0
	}
	if m.PlusX < 0 {
		m.PlusX = 0
	}
	if m.PlusY < 0 {
		m.PlusY = 0
	}
	return m
}

func validDeviceSerial(serial string) error {
	serial = strings.TrimSpace(serial)
	if len(serial) > 256 {
		return errors.New("ADB 设备标识过长")
	}
	if strings.ContainsAny(serial, "\r\n\t ") {
		return errors.New("ADB 设备标识包含非法空白字符")
	}
	return nil
}

func (s *ConfigStore) normalizeLocked() {
	s.data.Version = 3
	s.data.DeviceSerial = strings.TrimSpace(s.data.DeviceSerial)
	if s.data.ActiveMode < 1 || s.data.ActiveMode > 3 {
		s.data.ActiveMode = 1
	}
	modes := make([]TapMode, 3)
	copy(modes, s.data.Modes)
	for i := range modes {
		modes[i] = normalizeMode(modes[i])
	}
	s.data.Modes = modes
}

func (s *ConfigStore) saveLocked() error {
	raw, err := json.MarshalIndent(s.data, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, raw, 0o600); err != nil {
		return err
	}
	if err := os.Rename(tmp, s.path); err == nil {
		return nil
	}
	if err := os.Remove(s.path); err != nil && !os.IsNotExist(err) {
		return err
	}
	return os.Rename(tmp, s.path)
}

func (s *ConfigStore) Get() Config {
	s.mu.RLock()
	defer s.mu.RUnlock()
	c := s.data
	c.Modes = append([]TapMode(nil), s.data.Modes...)
	return c
}
func (s *ConfigStore) ActiveTapMode() (int, TapMode) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	mode := s.data.ActiveMode
	idx := mode - 1
	if idx < 0 || idx >= len(s.data.Modes) {
		return 1, TapMode{}
	}
	return mode, s.data.Modes[idx]
}
func (s *ConfigStore) Update(c Config) (Config, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	previous := s.data
	s.data = c
	s.normalizeLocked()
	if err := validDeviceSerial(s.data.DeviceSerial); err != nil {
		s.data = previous
		return Config{}, err
	}
	if err := s.saveLocked(); err != nil {
		s.data = previous
		return Config{}, err
	}
	out := s.data
	out.Modes = append([]TapMode(nil), s.data.Modes...)
	return out, nil
}
func (s *ConfigStore) SetDeviceSerial(serial string) (Config, error) {
	serial = strings.TrimSpace(serial)
	if err := validDeviceSerial(serial); err != nil {
		return Config{}, err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	previous := s.data
	s.data.DeviceSerial = serial
	s.normalizeLocked()
	if err := s.saveLocked(); err != nil {
		s.data = previous
		return Config{}, err
	}
	out := s.data
	out.Modes = append([]TapMode(nil), s.data.Modes...)
	return out, nil
}
func (s *ConfigStore) SetActiveMode(mode int) (Config, error) {
	if mode < 1 || mode > 3 {
		return Config{}, errors.New("模式必须是 1、2 或 3")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	previous := s.data
	s.data.ActiveMode = mode
	if err := s.saveLocked(); err != nil {
		s.data = previous
		return Config{}, err
	}
	out := s.data
	out.Modes = append([]TapMode(nil), s.data.Modes...)
	return out, nil
}
func (c Config) CurrentMode() TapMode {
	idx := c.ActiveMode - 1
	if idx < 0 || idx >= len(c.Modes) {
		return TapMode{}
	}
	return c.Modes[idx]
}
func validCoordinate(x, y int) bool { return x >= 0 && y >= 0 && (x != 0 || y != 0) }

package main

import (
	"sync"
	"time"
)

type Status struct {
	Connected  bool   `json:"connected"`
	Serial     string `json:"serial"`
	Busy       bool   `json:"busy"`
	LastAction string `json:"lastAction"`
	LastError  string `json:"lastError"`
	UpdatedAt  string `json:"updatedAt"`
}

type StatusStore struct {
	mu   sync.RWMutex
	data Status
}

func newStatusStore() *StatusStore {
	return &StatusStore{data: Status{LastAction: "程序已启动，请检测并连接 ADB 设备", UpdatedAt: time.Now().Format("15:04:05")}}
}
func (s *StatusStore) patch(fn func(*Status)) {
	s.mu.Lock()
	defer s.mu.Unlock()
	fn(&s.data)
	s.data.UpdatedAt = time.Now().Format("15:04:05")
}
func (s *StatusStore) Get() Status { s.mu.RLock(); defer s.mu.RUnlock(); return s.data }
func (s *StatusStore) Action(v string) {
	s.patch(func(d *Status) { d.LastAction = v; d.LastError = "" })
}
func (s *StatusStore) Error(v string) { s.patch(func(d *Status) { d.LastError = v }) }
func (s *StatusStore) Connection(ok bool, serial string) {
	s.patch(func(d *Status) {
		d.Connected = ok
		d.Serial = serial
		if !ok {
			d.Busy = false
		}
	})
}
func (s *StatusStore) SetBusy(v bool) { s.patch(func(d *Status) { d.Busy = v }) }

@echo off
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go test ./...
if errorlevel 1 exit /b 1
go build -buildvcs=false -trimpath -ldflags "-s -w -H=windowsgui" -o QAA-ADB-Tap-v1.2.0-DirectADB.exe .

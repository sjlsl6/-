module qaa-adb-tap

go 1.23

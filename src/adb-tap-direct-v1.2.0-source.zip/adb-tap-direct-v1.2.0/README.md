# QAA ADB Tap v1.2.0 DirectADB 源码

这是 `QAA-ADB-Tap-v1.2.0-DirectADB.exe` 对应的完整 Go 源码归档。它直接读取
`adb devices -l`，适用于雷电模拟器或已经授权 USB 调试的 Android 真机；
不执行无线配对、mDNS 发现或 `adb connect`。

Windows 10/11 amd64 用户可安装 Go 1.23.2（或兼容的 Go 1.23 版本），运行
`build_windows.cmd`。脚本会先执行全部测试，再生成 Windows GUI 程序。

已验证正式 EXE 的 SHA-256：

`933ac71e5d68b8a6e7d52968c298b758c2cb55bde93611234ce33ea392453cd2`

运行时 `config.json`、设备序列号和点击坐标不包含在此源码包中。

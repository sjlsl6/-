//go:build !windows

package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func installFakeADB(t *testing.T, script string) (string, string) {
	t.Helper()
	dir := t.TempDir()
	adbPath := filepath.Join(dir, "adb.exe")
	if err := os.WriteFile(adbPath, []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"AdbWinApi.dll", "AdbWinUsbApi.dll"} {
		if err := os.WriteFile(filepath.Join(dir, name), []byte("test"), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	old := os.Getenv("PATH")
	t.Cleanup(func() { _ = os.Setenv("PATH", old) })
	_ = os.Setenv("PATH", dir+string(os.PathListSeparator)+old)
	return dir, adbPath
}

func TestDirectDeviceConnectAndTap(t *testing.T) {
	logPath := filepath.Join(t.TempDir(), "tap.log")
	script := `#!/bin/sh
if [ "$1" = "devices" ] && [ "$2" = "-l" ]; then echo "List of devices attached"; echo "emulator-5554 device product:ld model:LDPlayer transport_id:1"; exit 0; fi
if [ "$1" = "-s" ] && [ "$2" = "emulator-5554" ] && [ "$3" = "get-state" ]; then echo device; exit 0; fi
if [ "$1" = "-s" ] && [ "$2" = "emulator-5554" ] && [ "$3" = "shell" ]; then
  while IFS= read -r line; do
    case "$line" in
      echo\ __QAA_READY_*) echo "${line#echo }" ;;
      *echo\ __QAA_WARM_*) echo "${line##*echo }" ;;
      input\ tap*) echo "$line" >> "$QAA_TEST_TAP_LOG" ;;
    esac
  done
  exit 0
fi
exit 1
`
	installFakeADB(t, script)
	old := os.Getenv("QAA_TEST_TAP_LOG")
	t.Cleanup(func() { _ = os.Setenv("QAA_TEST_TAP_LOG", old) })
	_ = os.Setenv("QAA_TEST_TAP_LOG", logPath)
	a := newADBManager(newStatusStore())
	t.Cleanup(a.Stop)
	serial, err := a.ConnectDirect("")
	if err != nil {
		t.Fatal(err)
	}
	if serial != "emulator-5554" {
		t.Fatalf("serial=%s", serial)
	}
	if err := a.Trigger(123, 456, "减号"); err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		raw, _ := os.ReadFile(logPath)
		if strings.Contains(string(raw), "input tap 123 456") {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	raw, _ := os.ReadFile(logPath)
	t.Fatalf("tap not observed: %q", raw)
}

func TestDirectConnectRequiresChoiceWhenMultipleDevices(t *testing.T) {
	script := `#!/bin/sh
if [ "$1" = "devices" ]; then echo "List of devices attached"; echo "emulator-5554 device"; echo "USB123 device"; exit 0; fi
exit 1
`
	installFakeADB(t, script)
	a := newADBManager(newStatusStore())
	t.Cleanup(a.Stop)
	if _, err := a.ConnectDirect(""); err == nil || !strings.Contains(err.Error(), "多个") {
		t.Fatalf("err=%v", err)
	}
}

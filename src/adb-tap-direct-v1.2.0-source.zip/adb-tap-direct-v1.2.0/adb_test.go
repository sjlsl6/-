package main

import (
	"strings"
	"testing"
	"time"
)

func TestTapQueueDoesNotGrowWithoutBound(t *testing.T) {
	a := &ADBManager{requests: make(chan tapRequest, 2)}
	a.requests <- tapRequest{}
	a.requests <- tapRequest{}
	select {
	case a.requests <- tapRequest{}:
		t.Fatal("queue unexpectedly accepted third request")
	default:
	}
	if len(a.requests) != 2 {
		t.Fatal("wrong queue length")
	}
	_ = time.Second
}

func TestOutputLooksFailed(t *testing.T) {
	for _, s := range []string{"failed to connect", "device offline", "connection refused"} {
		if !outputLooksFailed(s) {
			t.Fatalf("not detected: %s", s)
		}
	}
	if outputLooksFailed("List of devices attached") {
		t.Fatal("success classified as failure")
	}
}

func TestParseADBDevices(t *testing.T) {
	out := "List of devices attached\nemulator-5554 device product:sdk model:Android_SDK device:emu transport_id:1\n127.0.0.1:5555 offline transport_id:2\nUSB123 unauthorized usb:1-2\n"
	got := parseADBDevices(out)
	if len(got) != 3 {
		t.Fatalf("devices=%#v", got)
	}
	if got[0].Serial != "emulator-5554" || got[0].State != "device" {
		t.Fatalf("first=%#v", got[0])
	}
	if !strings.Contains(got[0].Details, "model:Android_SDK") {
		t.Fatalf("details=%q", got[0].Details)
	}
}

func TestChooseADBDevice(t *testing.T) {
	one := []ADBDevice{{Serial: "emulator-5554", State: "device"}}
	if got, err := chooseADBDevice(one, ""); err != nil || got != "emulator-5554" {
		t.Fatalf("got=%q err=%v", got, err)
	}
	many := []ADBDevice{{Serial: "A", State: "device"}, {Serial: "B", State: "device"}}
	if got, err := chooseADBDevice(many, "B"); err != nil || got != "B" {
		t.Fatalf("preferred got=%q err=%v", got, err)
	}
	if _, err := chooseADBDevice(many, ""); err == nil {
		t.Fatal("expected multi-device selection error")
	}
	if _, err := chooseADBDevice([]ADBDevice{{Serial: "A", State: "unauthorized"}}, ""); err == nil || !strings.Contains(err.Error(), "unauthorized") {
		t.Fatalf("err=%v", err)
	}
}

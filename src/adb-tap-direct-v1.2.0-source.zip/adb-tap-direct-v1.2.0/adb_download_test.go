package main

import (
	"archive/zip"
	"os"
	"path/filepath"
	"testing"
)

func TestExtractADBFiles(t *testing.T) {
	dir := t.TempDir()
	archive := filepath.Join(dir, "bundle.zip")
	f, err := os.Create(archive)
	if err != nil {
		t.Fatal(err)
	}
	zw := zip.NewWriter(f)
	for _, name := range []string{"root/adb.exe", "root/AdbWinApi.dll", "root/AdbWinUsbApi.dll", "root/ignored.txt"} {
		w, err := zw.Create(name)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := w.Write([]byte("test-" + name)); err != nil {
			t.Fatal(err)
		}
	}
	if err := zw.Close(); err != nil {
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	target := filepath.Join(dir, "platform-tools")
	if err := extractADBFiles(archive, target); err != nil {
		t.Fatal(err)
	}
	for name := range adbRequiredFiles {
		if _, err := os.Stat(filepath.Join(target, name)); err != nil {
			t.Fatalf("missing %s: %v", name, err)
		}
	}
	if _, err := os.Stat(filepath.Join(target, "ignored.txt")); !os.IsNotExist(err) {
		t.Fatal("unexpected file extracted")
	}
}

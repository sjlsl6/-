package main

import (
	"archive/zip"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const (
	adbBundleURL    = "https://github.com/Genymobile/scrcpy/releases/download/v4.0/scrcpy-win64-v4.0.zip"
	adbBundleSHA256 = "75dbeb5b00e6f64292f26f70900ae55ca397786bdfb0b9bbeb481a0549047457"
	maxADBZipBytes  = int64(64 << 20)
)

var adbRequiredFiles = map[string]bool{
	"adb.exe":          true,
	"AdbWinApi.dll":    true,
	"AdbWinUsbApi.dll": true,
}

func (a *ADBManager) ADBAvailable() bool {
	_, err := a.findADB()
	return err == nil
}

func (a *ADBManager) DownloadADB() (string, error) {
	a.connectMu.Lock()
	defer a.connectMu.Unlock()
	if p, err := a.findADB(); err == nil {
		return p, nil
	}
	cfgDir, err := configDirectory()
	if err != nil {
		return "", err
	}
	tmpZip := filepath.Join(cfgDir, "adb-download.tmp.zip")
	_ = os.Remove(tmpZip)
	defer os.Remove(tmpZip)

	client := &http.Client{Timeout: 5 * time.Minute}
	req, err := http.NewRequest(http.MethodGet, adbBundleURL, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("User-Agent", "QAA-ADB-Tap/1.1")
	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("ADB 下载失败：%w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", fmt.Errorf("ADB 下载失败：HTTP %d", resp.StatusCode)
	}
	if resp.ContentLength > maxADBZipBytes {
		return "", errors.New("ADB 下载文件异常过大")
	}
	f, err := os.OpenFile(tmpZip, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0o600)
	if err != nil {
		return "", err
	}
	n, copyErr := io.Copy(f, io.LimitReader(resp.Body, maxADBZipBytes+1))
	closeErr := f.Close()
	if copyErr != nil {
		return "", fmt.Errorf("ADB 下载中断：%w", copyErr)
	}
	if closeErr != nil {
		return "", closeErr
	}
	if n > maxADBZipBytes {
		return "", errors.New("ADB 下载文件超过安全大小限制")
	}
	if err := verifyFileSHA256(tmpZip, adbBundleSHA256); err != nil {
		return "", err
	}
	target := filepath.Join(cfgDir, "platform-tools")
	if err := extractADBFiles(tmpZip, target); err != nil {
		return "", err
	}
	adb := filepath.Join(target, "adb.exe")
	if _, err := os.Stat(adb); err != nil {
		return "", errors.New("ADB 文件准备完成后仍未找到 adb.exe")
	}
	a.status.Action("ADB 已一次性准备完成；以后不会重复下载")
	return adb, nil
}

func verifyFileSHA256(path, expected string) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return err
	}
	got := hex.EncodeToString(h.Sum(nil))
	if !strings.EqualFold(got, expected) {
		return fmt.Errorf("ADB 下载文件校验失败：得到 %s", got)
	}
	return nil
}

func extractADBFiles(zipPath, targetDir string) error {
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return fmt.Errorf("ADB 压缩包无法打开：%w", err)
	}
	defer zr.Close()

	tmpDir := targetDir + ".new"
	_ = os.RemoveAll(tmpDir)
	if err := os.MkdirAll(tmpDir, 0o755); err != nil {
		return err
	}
	defer os.RemoveAll(tmpDir)

	found := map[string]bool{}
	for _, zf := range zr.File {
		base := filepath.Base(filepath.FromSlash(zf.Name))
		if !adbRequiredFiles[base] || zf.FileInfo().IsDir() {
			continue
		}
		if zf.UncompressedSize64 > 32<<20 {
			return fmt.Errorf("ADB 文件 %s 异常过大", base)
		}
		r, err := zf.Open()
		if err != nil {
			return err
		}
		outPath := filepath.Join(tmpDir, base)
		out, err := os.OpenFile(outPath, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0o755)
		if err != nil {
			r.Close()
			return err
		}
		_, copyErr := io.Copy(out, io.LimitReader(r, 32<<20))
		closeOutErr := out.Close()
		closeInErr := r.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeOutErr != nil {
			return closeOutErr
		}
		if closeInErr != nil {
			return closeInErr
		}
		found[base] = true
	}
	for name := range adbRequiredFiles {
		if !found[name] {
			return fmt.Errorf("下载包内缺少 %s", name)
		}
	}
	_ = os.RemoveAll(targetDir)
	if err := os.Rename(tmpDir, targetDir); err != nil {
		return err
	}
	return nil
}

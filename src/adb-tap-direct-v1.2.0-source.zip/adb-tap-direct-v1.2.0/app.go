package main

import (
	"context"
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"net"
	"net/http"
	"sync"
	"time"
)

//go:embed web/*
var webFiles embed.FS

type App struct {
	config      *ConfigStore
	status      *StatusStore
	adb         *ADBManager
	server      *http.Server
	listener    net.Listener
	settingsURL string
	stopOnce    sync.Once
}

func NewApp() (*App, error) {
	cfg, err := newConfigStore()
	if err != nil {
		return nil, err
	}
	st := newStatusStore()
	a := &App{config: cfg, status: st}
	a.adb = newADBManager(st)
	return a, nil
}

func (a *App) Start() error {
	mux := http.NewServeMux()
	a.routes(mux)
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return err
	}
	a.listener = ln
	a.settingsURL = "http://" + ln.Addr().String() + "/"
	a.server = &http.Server{Handler: localOnly(mux), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 20 * time.Second, WriteTimeout: 30 * time.Second, IdleTimeout: 30 * time.Second, MaxHeaderBytes: 16 * 1024}
	go func() {
		if err := a.server.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
			a.status.Error("设置服务异常：" + err.Error())
		}
	}()
	return nil
}

func localOnly(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		host, _, err := net.SplitHostPort(r.RemoteAddr)
		if err != nil || (host != "127.0.0.1" && host != "::1") {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'")
		next.ServeHTTP(w, r)
	})
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	raw, _ := json.Marshal(v)
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	_, _ = w.Write(raw)
}
func readJSON(w http.ResponseWriter, r *http.Request, dst any) error {
	r.Body = http.MaxBytesReader(w, r.Body, 64*1024)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	return dec.Decode(dst)
}

func (a *App) routes(m *http.ServeMux) {
	m.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" || r.Method != http.MethodGet {
			http.NotFound(w, r)
			return
		}
		body, err := fs.ReadFile(webFiles, "web/settings.html")
		if err != nil {
			http.Error(w, err.Error(), 500)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		_, _ = w.Write(body)
	})
	m.HandleFunc("/api/state", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "method", 405)
			return
		}
		writeJSON(w, 200, map[string]any{"config": a.config.Get(), "status": a.status.Get(), "version": appVersion, "adbAvailable": a.adb.ADBAvailable()})
	})
	m.HandleFunc("/api/devices", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "method", 405)
			return
		}
		devices, err := a.adb.ListDevices()
		if err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		writeJSON(w, 200, map[string]any{"ok": true, "devices": devices})
	})
	m.HandleFunc("/api/save", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method", 405)
			return
		}
		var c Config
		if err := readJSON(w, r, &c); err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": "设置内容无效"})
			return
		}
		before := a.config.Get().ActiveMode
		saved, err := a.config.Update(c)
		if err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		if saved.ActiveMode != before {
			a.status.Action(fmt.Sprintf("已切换到模式 %d；ADB 连接保持不变", saved.ActiveMode))
			notifyModeChanged(saved.ActiveMode)
		} else {
			a.status.Action("设置已保存")
		}
		writeJSON(w, 200, map[string]any{"ok": true, "config": saved})
	})
	m.HandleFunc("/api/adb/download", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method", http.StatusMethodNotAllowed)
			return
		}
		path, err := a.adb.DownloadADB()
		if err != nil {
			a.status.Error(err.Error())
			writeJSON(w, 400, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		writeJSON(w, 200, map[string]any{"ok": true, "path": path})
	})
	m.HandleFunc("/api/mode", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method", 405)
			return
		}
		var body struct {
			Mode int `json:"mode"`
		}
		if err := readJSON(w, r, &body); err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": "模式设置无效"})
			return
		}
		cfg, err := a.SetActiveMode(body.Mode)
		if err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		writeJSON(w, 200, map[string]any{"ok": true, "config": cfg})
	})
	m.HandleFunc("/api/connect", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method", 405)
			return
		}
		var c Config
		if err := readJSON(w, r, &c); err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": "设置内容无效"})
			return
		}
		saved, err := a.config.Update(c)
		if err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		serial, err := a.adb.ConnectDirect(saved.DeviceSerial)
		if err != nil {
			a.status.Error(err.Error())
			writeJSON(w, 400, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		saved, _ = a.config.SetDeviceSerial(serial)
		writeJSON(w, 200, map[string]any{"ok": true, "serial": serial, "config": saved})
	})
	m.HandleFunc("/api/disconnect", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method", 405)
			return
		}
		a.Disconnect()
		writeJSON(w, 200, map[string]any{"ok": true})
	})
	m.HandleFunc("/api/test/minus", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method", 405)
			return
		}
		_, m := a.config.ActiveTapMode()
		if err := a.adb.Trigger(m.MinusX, m.MinusY, "减号"); err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		writeJSON(w, 200, map[string]any{"ok": true})
	})
	m.HandleFunc("/api/test/plus", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method", 405)
			return
		}
		_, m := a.config.ActiveTapMode()
		if err := a.adb.Trigger(m.PlusX, m.PlusY, "加号"); err != nil {
			writeJSON(w, 400, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		writeJSON(w, 200, map[string]any{"ok": true})
	})
	m.HandleFunc("/api/exit", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method", 405)
			return
		}
		writeJSON(w, 200, map[string]any{"ok": true})
		go requestAppExit()
	})
}

func (a *App) TriggerMinus() error {
	_, m := a.config.ActiveTapMode()
	err := a.adb.Trigger(m.MinusX, m.MinusY, "减号")
	if err != nil {
		a.status.Error(err.Error())
	}
	return err
}
func (a *App) TriggerPlus() error {
	_, m := a.config.ActiveTapMode()
	err := a.adb.Trigger(m.PlusX, m.PlusY, "加号")
	if err != nil {
		a.status.Error(err.Error())
	}
	return err
}
func (a *App) ConnectSaved() error {
	c := a.config.Get()
	serial, err := a.adb.ConnectDirect(c.DeviceSerial)
	if err != nil {
		a.status.Error(err.Error())
		return err
	}
	_, _ = a.config.SetDeviceSerial(serial)
	return nil
}
func (a *App) SetActiveMode(mode int) (Config, error) {
	cfg, err := a.config.SetActiveMode(mode)
	if err == nil {
		a.status.Action(fmt.Sprintf("已切换到模式 %d；ADB 连接保持不变", mode))
		notifyModeChanged(mode)
	}
	return cfg, err
}
func (a *App) Disconnect()         { a.adb.Disconnect() }
func (a *App) SettingsURL() string { return a.settingsURL }
func (a *App) StatusText() string {
	s := a.status.Get()
	cfg := a.config.Get()
	state := "未连接"
	if s.Connected {
		state = "已连接：" + s.Serial
	}
	if s.LastError != "" {
		return fmt.Sprintf("%s\n当前模式：%d\n\n错误：%s\n\n最后操作：%s", state, cfg.ActiveMode, s.LastError, s.LastAction)
	}
	return fmt.Sprintf("%s\n当前模式：%d\n\n最后操作：%s", state, cfg.ActiveMode, s.LastAction)
}
func (a *App) Stop() {
	a.stopOnce.Do(func() {
		a.adb.Stop()
		if a.server != nil {
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			defer cancel()
			_ = a.server.Shutdown(ctx)
		}
		if a.listener != nil {
			_ = a.listener.Close()
		}
	})
}

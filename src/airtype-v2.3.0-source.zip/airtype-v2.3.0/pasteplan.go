package main

import (
	"strings"
	"time"
	"unicode/utf8"
)

const pasteChunkRunes = 20_000

// splitForPaste 只在字符边界切分，不添加或删除任何字符。
// 它会优先在接近上限的换行符处分块，以降低超长输入框的瞬时压力。
func splitForPaste(text string) []string {
	if utf8.RuneCountInString(text) <= pasteChunkRunes {
		return []string{text}
	}
	runes := []rune(text)
	chunks := make([]string, 0, (len(runes)+pasteChunkRunes-1)/pasteChunkRunes)
	for start := 0; start < len(runes); {
		end := start + pasteChunkRunes
		if end >= len(runes) {
			chunks = append(chunks, string(runes[start:]))
			break
		}
		// 最多向前寻找 2000 字，优先在段落边界切分。
		min := end - 2000
		if min < start+1 {
			min = start + 1
		}
		cut := end
		for i := end; i >= min; i-- {
			if runes[i-1] == '\n' {
				cut = i
				break
			}
		}
		chunks = append(chunks, string(runes[start:cut]))
		start = cut
	}
	return chunks
}

func pasteSettleDelay(chunk string) time.Duration {
	n := utf8.RuneCountInString(chunk)
	d := 70*time.Millisecond + time.Duration(n/1000)*6*time.Millisecond
	if strings.Contains(chunk, "\n") {
		d += 25 * time.Millisecond
	}
	if d < 80*time.Millisecond {
		d = 80 * time.Millisecond
	}
	if d > 350*time.Millisecond {
		d = 350 * time.Millisecond
	}
	return d
}

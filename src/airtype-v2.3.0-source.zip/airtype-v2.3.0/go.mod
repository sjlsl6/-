module qaa-airtype-official-tray

go 1.23

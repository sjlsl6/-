# QAA AirType v2.3.0 源码

这是 `QAA-AirType-Official-Tray-v2.3.0.exe` 对应的完整 Go 源码归档。项目是
QAA-Tools/qaa-airtype 的社区修改/扩展版本，不属于 QAA-Tools 官方发行版。

文件名中的 `Official` 是历史构建文件名，不代表本项目获得 QAA-Tools 官方背书或属于官方发行版。

Windows 10/11 amd64 用户可安装 Go 1.23.2（或兼容的 Go 1.23 版本），运行
`build_windows.cmd`。脚本会先执行全部测试，再生成 Windows GUI 程序。

已验证正式 EXE 的 SHA-256：

`0326275e8a0abed9d61b4ae713d9c0c84f2eb012632832f0bd72de82c2454cbc`

运行时配置 `config.json` 和随机 Token 不包含在此源码包中。

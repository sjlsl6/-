package main

import (
	"fmt"
	"os"
	"runtime"
)

const appVersion = "2.3.0"

func main() {
	// Win32 窗口和消息循环必须始终留在创建它们的同一系统线程。
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	release, alreadyRunning, err := acquireSingleInstance()
	if err != nil {
		fatalMessage("程序初始化失败", err)
		return
	}
	if alreadyRunning {
		showFatal("QAA AirType 已在运行", "程序已经在系统托盘运行，请查看任务栏右下角的托盘图标。")
		return
	}
	if release != nil {
		defer release()
	}

	app, err := NewApp()
	if err != nil {
		fatalMessage("程序初始化失败", err)
		return
	}
	if err := app.Start(); err != nil {
		fatalMessage("程序启动失败", err)
		return
	}
	defer app.Stop()

	if err := runNativeTray(app); err != nil {
		fatalMessage("托盘程序异常", err)
	}
}

func fatalMessage(title string, err error) {
	showFatal(title, fmt.Sprint(err))
	_, _ = fmt.Fprintln(os.Stderr, title+":", err)
}

@echo off
setlocal
cd /d "%~dp0"
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go test ./...
if errorlevel 1 exit /b 1
go build -buildvcs=false -trimpath -ldflags "-H=windowsgui -s -w -buildid=N1kGQiO1P6MzOKbcXgXd/skKJPixqLtyG3qtgIffH/_rsAK9qPrzbXJoXR7YLR/TWbXoBLMtW9ip9oHsDoQ" -o QAA-AirType-Official-Tray-v2.3.0.exe .
if errorlevel 1 exit /b 1
echo Build complete: QAA-AirType-Official-Tray-v2.3.0.exe

//go:build !windows

package main

import "errors"

func pasteAndSend(text string) error               { return nil }
func openBrowser(url string) error                 { return nil }
func setClipboardText(text string) error           { return nil }
func showFatal(title, message string)              {}
func runNativeTray(app *App) error                 { return errors.New("此程序仅支持 Windows") }
func acquireSingleInstance() (func(), bool, error) { return func() {}, false, nil }

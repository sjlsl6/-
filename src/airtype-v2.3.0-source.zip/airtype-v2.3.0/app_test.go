package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"sync/atomic"
	"testing"
	"time"
	"unicode/utf8"
)

func testApp(t *testing.T) *App {
	t.Helper()
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	a, err := NewApp()
	if err != nil {
		t.Fatal(err)
	}
	return a
}

func doJSON(mux http.Handler, method, path, token string, body any) *httptest.ResponseRecorder {
	data, _ := json.Marshal(body)
	req := httptest.NewRequest(method, path, bytes.NewReader(data))
	req.Header.Set("Content-Type", "application/json")
	if token != "" {
		req.Header.Set("X-QAA-Token", token)
	}
	w := httptest.NewRecorder()
	mux.ServeHTTP(w, req)
	return w
}

func TestAuthAndPhonePage(t *testing.T) {
	a := testApp(t)
	mux := http.NewServeMux()
	a.registerRoutes(mux)

	w := httptest.NewRecorder()
	mux.ServeHTTP(w, httptest.NewRequest(http.MethodGet, "/", nil))
	if w.Code != http.StatusForbidden {
		t.Fatalf("unauthorized root = %d", w.Code)
	}

	w = httptest.NewRecorder()
	mux.ServeHTTP(w, httptest.NewRequest(http.MethodGet, "/?token="+a.config.Token, nil))
	if w.Code != http.StatusOK {
		t.Fatalf("authorized root = %d", w.Code)
	}
	page := w.Body.String()
	for _, want := range []string{
		`enterkeyhint="enter"`, `indexedDB`, `fetch('/type'`, `最近 10 条`,
		`清空未发送`, `恢复到输入框`, `event.keyCode===229`, `compositionstart`,
		`电脑已连接`, `submitCurrentText`,
	} {
		if !strings.Contains(page, want) {
			t.Fatalf("phone page missing %q", want)
		}
	}
	for _, forbidden := range []string{
		"/api/upload/start", "/api/upload/chunk", "/api/upload/finish",
		"正在连接电脑", "自动重试", "processQueue", "input.readOnly", "readOnly=true",
	} {
		if strings.Contains(page, forbidden) {
			t.Fatalf("phone page contains removed logic %q", forbidden)
		}
	}
	if strings.Contains(page, "__QAA_TOKEN__") {
		t.Fatal("token placeholder was not replaced")
	}
}

func TestDirectTypeSendsExactlyOnce(t *testing.T) {
	a := testApp(t)
	var calls atomic.Int32
	var got string
	a.sender.sendFn = func(text string) error {
		calls.Add(1)
		got = text
		return nil
	}
	mux := http.NewServeMux()
	a.registerRoutes(mux)
	text := "第一段🙂\n第二段"
	w := doJSON(mux, http.MethodPost, "/type", a.config.Token, map[string]any{"text": text})
	if w.Code != http.StatusOK {
		t.Fatalf("type: %d %s", w.Code, w.Body.String())
	}
	if calls.Load() != 1 || got != text {
		t.Fatalf("calls=%d got=%q", calls.Load(), got)
	}
	if a.status.Get().SendCount != 1 {
		t.Fatal("status was not updated")
	}
}

func TestSenderRejectsConcurrentRequestWithoutQueueing(t *testing.T) {
	s := newSender(newStatusStore())
	started := make(chan struct{})
	release := make(chan struct{})
	var calls atomic.Int32
	s.sendFn = func(text string) error {
		calls.Add(1)
		close(started)
		<-release
		return nil
	}
	firstDone := make(chan error, 1)
	go func() { firstDone <- s.Send("第一段") }()
	<-started
	if err := s.Send("第二段"); !errors.Is(err, ErrSendBusy) {
		t.Fatalf("busy error=%v", err)
	}
	if calls.Load() != 1 {
		t.Fatalf("second request entered sender: %d", calls.Load())
	}
	close(release)
	if err := <-firstDone; err != nil {
		t.Fatal(err)
	}
}

func TestValidationAndRequestErrors(t *testing.T) {
	a := testApp(t)
	mux := http.NewServeMux()
	a.registerRoutes(mux)

	cases := []struct {
		name string
		body any
	}{
		{"empty", map[string]any{"text": "   \n"}},
		{"nul", map[string]any{"text": "a\u0000b"}},
		{"unknown", map[string]any{"text": "ok", "extra": true}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			w := doJSON(mux, http.MethodPost, "/type", a.config.Token, tc.body)
			if w.Code != http.StatusBadRequest {
				t.Fatalf("status=%d body=%s", w.Code, w.Body.String())
			}
		})
	}
	w := doJSON(mux, http.MethodPost, "/type", "wrong", map[string]any{"text": "abc"})
	if w.Code != http.StatusForbidden {
		t.Fatalf("auth status=%d", w.Code)
	}
	w = doJSON(mux, http.MethodGet, "/type", a.config.Token, nil)
	if w.Code != http.StatusMethodNotAllowed {
		t.Fatalf("method status=%d", w.Code)
	}
}

func TestSenderErrorIsReturnedAndTextIsNotStoredOnComputer(t *testing.T) {
	a := testApp(t)
	a.sender.sendFn = func(text string) error { return errors.New("模拟剪贴板失败") }
	mux := http.NewServeMux()
	a.registerRoutes(mux)
	w := doJSON(mux, http.MethodPost, "/type", a.config.Token, map[string]any{"text": "不会写入电脑历史"})
	if w.Code != http.StatusInternalServerError || !strings.Contains(w.Body.String(), "模拟剪贴板失败") {
		t.Fatalf("status=%d body=%s", w.Code, w.Body.String())
	}
	if a.status.Get().SendCount != 0 {
		t.Fatal("failed send counted as success")
	}
}

func TestSplitForPastePreservesAllText(t *testing.T) {
	text := strings.Repeat("甲乙丙🙂\n", 12000) + "结尾"
	chunks := splitForPaste(text)
	if len(chunks) < 2 {
		t.Fatal("expected multiple chunks")
	}
	if got := strings.Join(chunks, ""); got != text {
		t.Fatalf("split changed text: got runes=%d want=%d", utf8.RuneCountInString(got), utf8.RuneCountInString(text))
	}
	for _, chunk := range chunks {
		if !utf8.ValidString(chunk) {
			t.Fatal("invalid UTF-8 chunk")
		}
		if utf8.RuneCountInString(chunk) > pasteChunkRunes {
			t.Fatalf("chunk too large: %d", utf8.RuneCountInString(chunk))
		}
	}
}

func TestTextLimits(t *testing.T) {
	if _, err := validateText(strings.Repeat("甲", maxTextRunes+1)); err == nil {
		t.Fatal("rune limit not enforced")
	}
	if _, err := validateText(strings.Repeat("a", maxTextBytes+1)); err == nil {
		t.Fatal("byte limit not enforced")
	}
	if count, err := validateText("中文🙂"); err != nil || count != 3 {
		t.Fatalf("count=%d err=%v", count, err)
	}
}

func TestConfigTokenPersists(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", dir)
	first, err := loadOrCreateConfig()
	if err != nil {
		t.Fatal(err)
	}
	second, err := loadOrCreateConfig()
	if err != nil {
		t.Fatal(err)
	}
	if first.Token == "" || first.Token != second.Token {
		t.Fatal("token did not persist")
	}
	if _, err := os.Stat(dir); err != nil {
		t.Fatal(err)
	}
}

func TestRealHTTPServerStartAndStop(t *testing.T) {
	a := testApp(t)
	a.config.Port = 0
	if err := a.Start(); err != nil {
		t.Fatal(err)
	}
	tcp, ok := a.listener.Addr().(*net.TCPAddr)
	if !ok {
		t.Fatalf("listener addr type %T", a.listener.Addr())
	}
	url := fmt.Sprintf("http://127.0.0.1:%d/?token=%s", tcp.Port, a.config.Token)
	client := &http.Client{Timeout: 3 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		t.Fatal(err)
	}
	_ = resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status=%d", resp.StatusCode)
	}
	a.Stop()
	ln, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", tcp.Port))
	if err != nil {
		t.Fatalf("port not released: %v", err)
	}
	_ = ln.Close()
}

func TestSlowSendDoesNotTimeOutServerWriterPrematurely(t *testing.T) {
	a := testApp(t)
	a.sender.sendFn = func(text string) error {
		time.Sleep(50 * time.Millisecond)
		return nil
	}
	mux := http.NewServeMux()
	a.registerRoutes(mux)
	w := doJSON(mux, http.MethodPost, "/type", a.config.Token, map[string]any{"text": "慢速处理"})
	if w.Code != http.StatusOK {
		t.Fatalf("status=%d %s", w.Code, w.Body.String())
	}
}

func TestCopyPhoneURLDoesNotReturnLocalhostForPhone(t *testing.T) {
	a := testApp(t)
	a.networkMu.Lock()
	a.lanAddrs = nil
	a.networkMu.Unlock()
	if a.PrimaryPhoneURL() != "" {
		t.Fatalf("unexpected phone URL: %q", a.PrimaryPhoneURL())
	}
	if err := a.CopyPhoneURL(); err == nil {
		t.Fatal("expected clear error when no LAN address exists")
	}
}

func TestLargeUnicodeRequestUsesSingleTypeCall(t *testing.T) {
	a := testApp(t)
	text := strings.Repeat("长文本🙂\n", 25_000)
	var calls atomic.Int32
	a.sender.sendFn = func(got string) error {
		calls.Add(1)
		if got != text {
			t.Fatal("large request text changed")
		}
		return nil
	}
	mux := http.NewServeMux()
	a.registerRoutes(mux)
	w := doJSON(mux, http.MethodPost, "/type", a.config.Token, map[string]any{"text": text})
	if w.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", w.Code, w.Body.String())
	}
	if calls.Load() != 1 {
		t.Fatalf("calls=%d", calls.Load())
	}
}

func TestTypeRouteReturnsConflictWhileBusy(t *testing.T) {
	a := testApp(t)
	started := make(chan struct{})
	release := make(chan struct{})
	a.sender.sendFn = func(text string) error {
		close(started)
		<-release
		return nil
	}
	mux := http.NewServeMux()
	a.registerRoutes(mux)
	firstDone := make(chan *httptest.ResponseRecorder, 1)
	go func() {
		firstDone <- doJSON(mux, http.MethodPost, "/type", a.config.Token, map[string]any{"text": "第一段"})
	}()
	<-started
	second := doJSON(mux, http.MethodPost, "/type", a.config.Token, map[string]any{"text": "第二段"})
	if second.Code != http.StatusConflict || !strings.Contains(second.Body.String(), "上一段") {
		t.Fatalf("status=%d body=%s", second.Code, second.Body.String())
	}
	close(release)
	if first := <-firstDone; first.Code != http.StatusOK {
		t.Fatalf("first status=%d", first.Code)
	}
}

func TestPhoneAddressLinesShowInterfaceAndNeverHideToken(t *testing.T) {
	a := testApp(t)
	a.networkMu.Lock()
	a.lanAddrs = []lanAddress{{IP: "192.168.1.9", Iface: "以太网", Score: 108}}
	a.networkMu.Unlock()
	lines := a.CachedPhoneAddressLines()
	if len(lines) != 1 || !strings.Contains(lines[0], "以太网") || !strings.Contains(lines[0], "192.168.1.9") || !strings.Contains(lines[0], a.config.Token) {
		t.Fatalf("lines=%v", lines)
	}
}

func TestLocalQRCodePageAndImage(t *testing.T) {
	a := testApp(t)
	a.networkMu.Lock()
	a.lanAddrs = []lanAddress{{IP: "192.168.1.8", Iface: "以太网", Score: 100}}
	a.networkMu.Unlock()
	mux := http.NewServeMux()
	a.registerRoutes(mux)

	req := httptest.NewRequest(http.MethodGet, "/qr", nil)
	req.RemoteAddr = "127.0.0.1:12345"
	w := httptest.NewRecorder()
	mux.ServeHTTP(w, req)
	if w.Code != http.StatusOK || !strings.Contains(w.Body.String(), "手机扫码打开 AirType") {
		t.Fatalf("qr page status=%d body=%s", w.Code, w.Body.String())
	}

	req = httptest.NewRequest(http.MethodGet, "/qr.png", nil)
	req.RemoteAddr = "127.0.0.1:12345"
	w = httptest.NewRecorder()
	mux.ServeHTTP(w, req)
	if w.Code != http.StatusOK || w.Header().Get("Content-Type") != "image/png" || !bytes.HasPrefix(w.Body.Bytes(), []byte{0x89, 'P', 'N', 'G'}) {
		t.Fatalf("qr png status=%d type=%s", w.Code, w.Header().Get("Content-Type"))
	}

	req = httptest.NewRequest(http.MethodGet, "/qr", nil)
	req.RemoteAddr = "192.168.1.9:12345"
	w = httptest.NewRecorder()
	mux.ServeHTTP(w, req)
	if w.Code != http.StatusForbidden {
		t.Fatalf("remote qr page should be forbidden, got %d", w.Code)
	}
}

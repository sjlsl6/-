package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
)

type Config struct {
	Token string `json:"token"`
	Port  int    `json:"port"`
}

func appDataDir() (string, error) {
	dir, err := os.UserConfigDir()
	if err != nil || dir == "" {
		dir = os.TempDir()
	}
	dir = filepath.Join(dir, "QAA-AirType")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", fmt.Errorf("创建配置目录失败：%w", err)
	}
	return dir, nil
}

func writeJSONAtomic(path string, value any) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, data, 0o600); err != nil {
		return err
	}
	if err := os.Rename(tmp, path); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

func loadOrCreateConfig() (Config, error) {
	dir, err := appDataDir()
	if err != nil {
		return Config{}, err
	}
	path := filepath.Join(dir, "config.json")

	cfg := Config{Port: 5000}
	if data, err := os.ReadFile(path); err == nil {
		_ = json.Unmarshal(data, &cfg)
	}
	if cfg.Port < 1024 || cfg.Port > 65535 {
		cfg.Port = 5000
	}
	if len(cfg.Token) < 32 {
		raw := make([]byte, 24)
		if _, err := rand.Read(raw); err != nil {
			return Config{}, fmt.Errorf("生成安全令牌失败：%w", err)
		}
		cfg.Token = hex.EncodeToString(raw)
	}
	if err := writeJSONAtomic(path, cfg); err != nil {
		return Config{}, fmt.Errorf("保存配置失败：%w", err)
	}
	return cfg, nil
}

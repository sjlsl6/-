package main

import (
	"net"
	"testing"
)

func TestPrivateIPScore(t *testing.T) {
	cases := map[string]int{
		"192.168.1.2": 100,
		"10.0.0.2":    90,
		"172.20.0.2":  75,
		"8.8.8.8":     0,
	}
	for raw, want := range cases {
		if got := privateIPScore(net.ParseIP(raw)); got != want {
			t.Fatalf("%s got %d want %d", raw, got, want)
		}
	}
}

func TestVirtualInterfaceNames(t *testing.T) {
	for _, name := range []string{"Clash Wintun", "vEthernet (WSL)", "Tailscale", "DockerNAT", "TAP-Windows Adapter"} {
		if !isVirtualInterface(name) {
			t.Fatalf("expected virtual: %s", name)
		}
	}
	for _, name := range []string{"Ethernet", "Wi-Fi", "以太网", "无线网络连接"} {
		if isVirtualInterface(name) {
			t.Fatalf("expected physical candidate: %s", name)
		}
	}
}

func TestPhoneURLs(t *testing.T) {
	urls := phoneURLs(5000, "abc", []string{"192.168.1.8", "10.0.0.2"})
	if len(urls) != 2 || urls[0] != "http://192.168.1.8:5000/?token=abc" {
		t.Fatalf("urls=%v", urls)
	}
}

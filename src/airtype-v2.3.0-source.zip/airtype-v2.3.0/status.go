package main

import (
	"fmt"
	"sync"
	"time"
)

type Status struct {
	StartedAt     time.Time
	LastAction    string
	LastError     string
	LastPhoneSeen time.Time
	LastSendAt    time.Time
	SendCount     int
	LastChars     int
}

type StatusStore struct {
	mu sync.RWMutex
	s  Status
}

func newStatusStore() *StatusStore {
	return &StatusStore{s: Status{
		StartedAt:  time.Now(),
		LastAction: "程序已启动，等待手机打开网页",
	}}
}

func (x *StatusStore) Get() Status {
	x.mu.RLock()
	defer x.mu.RUnlock()
	return x.s
}

func (x *StatusStore) Action(msg string) {
	x.mu.Lock()
	x.s.LastAction = msg
	x.s.LastError = ""
	x.mu.Unlock()
}

func (x *StatusStore) Error(msg string) {
	x.mu.Lock()
	x.s.LastError = msg
	x.mu.Unlock()
}

func (x *StatusStore) MarkPhone() {
	x.mu.Lock()
	x.s.LastPhoneSeen = time.Now()
	x.mu.Unlock()
}

func (x *StatusStore) MarkSent(chars int) {
	x.mu.Lock()
	x.s.LastPhoneSeen = time.Now()
	x.s.LastSendAt = time.Now()
	x.s.SendCount++
	x.s.LastChars = chars
	x.s.LastAction = fmt.Sprintf("已接收并发送第 %d 条文字（%d 字）", x.s.SendCount, chars)
	x.s.LastError = ""
	x.mu.Unlock()
}

package main

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"unicode/utf8"
)

const (
	maxTextRunes = 5_000_000
	maxTextBytes = 32 * 1024 * 1024
)

var ErrSendBusy = errors.New("电脑正在处理上一段文字，请稍后再发送本轮内容")

type Sender struct {
	mu     sync.Mutex
	busy   bool
	sendFn func(string) error
	status *StatusStore
}

func newSender(status *StatusStore) *Sender {
	return &Sender{
		sendFn: pasteAndSend,
		status: status,
	}
}

func validateText(text string) (int, error) {
	if strings.TrimSpace(text) == "" {
		return 0, errors.New("输入内容为空")
	}
	if strings.IndexByte(text, 0) >= 0 {
		return 0, errors.New("内容包含无法粘贴的空字符")
	}
	if len(text) > maxTextBytes {
		return 0, fmt.Errorf("单次内容超过 32MB，请分成两次发送")
	}
	count := utf8.RuneCountInString(text)
	if count > maxTextRunes {
		return 0, fmt.Errorf("单次文字超过 %d 万字符，请分成两次发送", maxTextRunes/10000)
	}
	return count, nil
}

func (s *Sender) Send(text string) error {
	count, err := validateText(text)
	if err != nil {
		return err
	}

	s.mu.Lock()
	if s.busy {
		s.mu.Unlock()
		return ErrSendBusy
	}
	s.busy = true
	s.mu.Unlock()

	defer func() {
		s.mu.Lock()
		s.busy = false
		s.mu.Unlock()
	}()

	if err := s.sendFn(text); err != nil {
		s.status.Error("电脑端处理失败：" + err.Error())
		return err
	}
	s.status.MarkSent(count)
	return nil
}

func (s *Sender) IsBusy() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.busy
}

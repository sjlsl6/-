//go:build windows

package main

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")

	pOpenClipboard            = user32.NewProc("OpenClipboard")
	pCloseClipboard           = user32.NewProc("CloseClipboard")
	pEmptyClipboard           = user32.NewProc("EmptyClipboard")
	pSetClipboardData         = user32.NewProc("SetClipboardData")
	pSendInput                = user32.NewProc("SendInput")
	pGetForegroundWindow      = user32.NewProc("GetForegroundWindow")
	pGetWindowThreadProcessId = user32.NewProc("GetWindowThreadProcessId")
	pRegisterClassExW         = user32.NewProc("RegisterClassExW")
	pCreateWindowExW          = user32.NewProc("CreateWindowExW")
	pDefWindowProcW           = user32.NewProc("DefWindowProcW")
	pGetMessageW              = user32.NewProc("GetMessageW")
	pTranslateMessage         = user32.NewProc("TranslateMessage")
	pDispatchMessageW         = user32.NewProc("DispatchMessageW")
	pPostQuitMessage          = user32.NewProc("PostQuitMessage")
	pDestroyWindow            = user32.NewProc("DestroyWindow")
	pLoadCursorW              = user32.NewProc("LoadCursorW")
	pLoadIconW                = user32.NewProc("LoadIconW")
	pMessageBoxW              = user32.NewProc("MessageBoxW")
	pSetProcessDPIAware       = user32.NewProc("SetProcessDPIAware")
	pCreatePopupMenu          = user32.NewProc("CreatePopupMenu")
	pAppendMenuW              = user32.NewProc("AppendMenuW")
	pTrackPopupMenu           = user32.NewProc("TrackPopupMenu")
	pDestroyMenu              = user32.NewProc("DestroyMenu")
	pGetCursorPos             = user32.NewProc("GetCursorPos")
	pSetForegroundWindow      = user32.NewProc("SetForegroundWindow")
	pPostMessageW             = user32.NewProc("PostMessageW")
	pRegisterWindowMessageW   = user32.NewProc("RegisterWindowMessageW")

	pGetModuleHandleW    = kernel32.NewProc("GetModuleHandleW")
	pGlobalAlloc         = kernel32.NewProc("GlobalAlloc")
	pGlobalFree          = kernel32.NewProc("GlobalFree")
	pGlobalLock          = kernel32.NewProc("GlobalLock")
	pGlobalUnlock        = kernel32.NewProc("GlobalUnlock")
	pRtlMoveMemory       = kernel32.NewProc("RtlMoveMemory")
	pCreateMutexW        = kernel32.NewProc("CreateMutexW")
	pCloseHandle         = kernel32.NewProc("CloseHandle")
	pGetLastError        = kernel32.NewProc("GetLastError")
	pGetCurrentProcessId = kernel32.NewProc("GetCurrentProcessId")

	pShellExecuteW    = shell32.NewProc("ShellExecuteW")
	pShellNotifyIconW = shell32.NewProc("Shell_NotifyIconW")
)

const (
	CF_UNICODETEXT  = 13
	GMEM_MOVEABLE   = 0x0002
	INPUT_KEYBOARD  = 1
	KEYEVENTF_KEYUP = 0x0002
	VK_CONTROL      = 0x11
	VK_V            = 0x56
	VK_RETURN       = 0x0D

	WM_CREATE          = 0x0001
	WM_DESTROY         = 0x0002
	WM_CLOSE           = 0x0010
	WM_COMMAND         = 0x0111
	WM_NULL            = 0x0000
	WM_LBUTTONDBLCLK   = 0x0203
	WM_RBUTTONUP       = 0x0205
	WM_APP             = 0x8000
	WM_TRAYICON        = WM_APP + 1
	WM_NETWORK_READY   = WM_APP + 2
	WM_SHOW_BALLOON    = WM_APP + 3
	WS_OVERLAPPED      = 0x00000000
	COLOR_WINDOW       = 5
	IDC_ARROW          = 32512
	IDI_APPLICATION    = 32512
	MB_OK              = 0x00000000
	MB_ICONINFORMATION = 0x00000040
	MB_ICONERROR       = 0x00000010
	MB_TOPMOST         = 0x00040000

	NIM_ADD     = 0x00000000
	NIM_MODIFY  = 0x00000001
	NIM_DELETE  = 0x00000002
	NIF_MESSAGE = 0x00000001
	NIF_ICON    = 0x00000002
	NIF_TIP     = 0x00000004
	NIF_INFO    = 0x00000010
	NIIF_INFO   = 0x00000001
	NIIF_ERROR  = 0x00000003

	MF_STRING       = 0x00000000
	MF_SEPARATOR    = 0x00000800
	TPM_RIGHTBUTTON = 0x0002
	TPM_RETURNCMD   = 0x0100
	TPM_NONOTIFY    = 0x0080

	SW_SHOWNORMAL        = 1
	ERROR_ALREADY_EXISTS = 183

	cmdCopyURL  = 1001
	cmdShowQR   = 1002
	cmdOpenPage = 1003
	cmdStatus   = 1004
	cmdRefresh  = 1005
	cmdExit     = 1006
)

type keyboardInput struct {
	WVk         uint16
	WScan       uint16
	DwFlags     uint32
	Time        uint32
	DwExtraInfo uintptr
}

type input struct {
	Type uint32
	_    uint32
	Data [32]byte
}

var _ [40 - unsafe.Sizeof(input{})]byte
var _ [unsafe.Sizeof(input{}) - 40]byte

func keyboardEvent(vk uint16, flags uint32) input {
	in := input{Type: INPUT_KEYBOARD}
	ki := (*keyboardInput)(unsafe.Pointer(&in.Data[0]))
	ki.WVk = vk
	ki.DwFlags = flags
	return in
}

func openClipboardRetry() error {
	for i := 0; i < 50; i++ {
		if r, _, _ := pOpenClipboard.Call(0); r != 0 {
			return nil
		}
		time.Sleep(10 * time.Millisecond)
	}
	return errors.New("无法打开 Windows 剪贴板")
}

func setClipboardText(text string) error {
	u, err := syscall.UTF16FromString(text)
	if err != nil {
		return err
	}
	size := uintptr(len(u) * 2)
	h, _, _ := pGlobalAlloc.Call(GMEM_MOVEABLE, size)
	if h == 0 {
		return errors.New("剪贴板内存分配失败")
	}
	ptr, _, _ := pGlobalLock.Call(h)
	if ptr == 0 {
		pGlobalFree.Call(h)
		return errors.New("剪贴板内存锁定失败")
	}
	pRtlMoveMemory.Call(ptr, uintptr(unsafe.Pointer(&u[0])), size)
	pGlobalUnlock.Call(h)
	if err := openClipboardRetry(); err != nil {
		pGlobalFree.Call(h)
		return err
	}
	defer pCloseClipboard.Call()
	if r, _, _ := pEmptyClipboard.Call(); r == 0 {
		pGlobalFree.Call(h)
		return errors.New("清空剪贴板失败")
	}
	r, _, _ := pSetClipboardData.Call(CF_UNICODETEXT, h)
	if r == 0 {
		pGlobalFree.Call(h)
		return errors.New("写入剪贴板失败")
	}
	// SetClipboardData 成功后，内存所有权归系统，不能再 GlobalFree。
	return nil
}

func sendKeys(keys []input) error {
	if len(keys) == 0 {
		return nil
	}
	r, _, e := pSendInput.Call(uintptr(len(keys)), uintptr(unsafe.Pointer(&keys[0])), unsafe.Sizeof(keys[0]))
	if r != uintptr(len(keys)) {
		return fmt.Errorf("Windows 模拟按键失败（%d/%d）：%v", r, len(keys), e)
	}
	return nil
}

func sendPasteShortcut() error {
	return sendKeys([]input{
		keyboardEvent(VK_CONTROL, 0),
		keyboardEvent(VK_V, 0),
		keyboardEvent(VK_V, KEYEVENTF_KEYUP),
		keyboardEvent(VK_CONTROL, KEYEVENTF_KEYUP),
	})
}

func sendEnter() error {
	return sendKeys([]input{
		keyboardEvent(VK_RETURN, 0),
		keyboardEvent(VK_RETURN, KEYEVENTF_KEYUP),
	})
}

func foregroundTarget() (uintptr, error) {
	hwnd, _, _ := pGetForegroundWindow.Call()
	if hwnd == 0 {
		return 0, errors.New("没有检测到当前输入窗口，请先点击电脑上的目标输入框")
	}
	var pid uint32
	pGetWindowThreadProcessId.Call(hwnd, uintptr(unsafe.Pointer(&pid)))
	current, _, _ := pGetCurrentProcessId.Call()
	if uintptr(pid) == current {
		return 0, errors.New("当前焦点在 QAA AirType 窗口上，请关闭状态提示并点击目标输入框")
	}
	return hwnd, nil
}

func sameForeground(hwnd uintptr) bool {
	current, _, _ := pGetForegroundWindow.Call()
	return current == hwnd && current != 0
}

func pasteAndSend(text string) error {
	target, err := foregroundTarget()
	if err != nil {
		return err
	}
	chunks := splitForPaste(text)
	for i, chunk := range chunks {
		if !sameForeground(target) {
			if i == 0 {
				return errors.New("发送前电脑焦点发生变化，已停止；请重新点击目标输入框")
			}
			return fmt.Errorf("粘贴到第 %d/%d 段时电脑焦点发生变化，已停止。请先检查目标输入框，避免重复发送", i, len(chunks))
		}
		if err := setClipboardText(chunk); err != nil {
			return err
		}
		if err := sendPasteShortcut(); err != nil {
			return err
		}
		time.Sleep(pasteSettleDelay(chunk))
	}
	if !sameForeground(target) {
		return errors.New("文字已粘贴，但发送前电脑焦点发生变化，因此没有自动按回车；请检查后手动发送")
	}
	// 最后一段完成后再留出一小段时间，避免超长文本尚未落入网页输入框就触发回车。
	time.Sleep(100 * time.Millisecond)
	return sendEnter()
}

func openBrowser(url string) error {
	verb, _ := syscall.UTF16PtrFromString("open")
	target, _ := syscall.UTF16PtrFromString(url)
	r, _, _ := pShellExecuteW.Call(0, uintptr(unsafe.Pointer(verb)), uintptr(unsafe.Pointer(target)), 0, 0, SW_SHOWNORMAL)
	if r <= 32 {
		return fmt.Errorf("无法打开浏览器：%s", url)
	}
	return nil
}

func showMessage(title, message string, flags uintptr) {
	t, _ := syscall.UTF16PtrFromString(title)
	m, _ := syscall.UTF16PtrFromString(message)
	pMessageBoxW.Call(0, uintptr(unsafe.Pointer(m)), uintptr(unsafe.Pointer(t)), flags|MB_TOPMOST)
}

func showFatal(title, message string) {
	showMessage(title, message, MB_OK|MB_ICONERROR)
}

func acquireSingleInstance() (func(), bool, error) {
	name, _ := syscall.UTF16PtrFromString("Local\\QAA-AirType-Official-Tray-v2")
	h, _, callErr := pCreateMutexW.Call(0, 0, uintptr(unsafe.Pointer(name)))
	if h == 0 {
		return nil, false, fmt.Errorf("创建单实例锁失败：%v", callErr)
	}
	last, _, _ := pGetLastError.Call()
	if last == ERROR_ALREADY_EXISTS {
		pCloseHandle.Call(h)
		return nil, true, nil
	}
	return func() { pCloseHandle.Call(h) }, false, nil
}

type point struct{ X, Y int32 }
type msg struct {
	HWnd           uintptr
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             point
	LPrivate       uint32
}

type wndClassEx struct {
	Size       uint32
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	Instance   uintptr
	Icon       uintptr
	Cursor     uintptr
	Background uintptr
	MenuName   *uint16
	ClassName  *uint16
	IconSm     uintptr
}

type guid struct {
	Data1 uint32
	Data2 uint16
	Data3 uint16
	Data4 [8]byte
}

type notifyIconData struct {
	Size             uint32
	HWnd             uintptr
	ID               uint32
	Flags            uint32
	CallbackMessage  uint32
	Icon             uintptr
	Tip              [128]uint16
	State            uint32
	StateMask        uint32
	Info             [256]uint16
	TimeoutOrVersion uint32
	InfoTitle        [64]uint16
	InfoFlags        uint32
	GUID             guid
	BalloonIcon      uintptr
}

var (
	trayApp      *App
	trayHwnd     uintptr
	trayIcon     uintptr
	taskbarMsg   uint32
	trayAdded    bool
	balloonMu    sync.Mutex
	pendingTitle string
	pendingText  string
	pendingError bool
)

func utf16Copy(dst []uint16, text string) {
	src, _ := syscall.UTF16FromString(text)
	if len(src) > len(dst) {
		src = src[:len(dst)]
		src[len(src)-1] = 0
	}
	copy(dst, src)
}

func trayData(flags uint32) notifyIconData {
	n := notifyIconData{
		HWnd:            trayHwnd,
		ID:              1,
		Flags:           flags,
		CallbackMessage: WM_TRAYICON,
		Icon:            trayIcon,
	}
	n.Size = uint32(unsafe.Sizeof(n))
	utf16Copy(n.Tip[:], "QAA AirType - 手机语音输入")
	return n
}

func addTrayIcon() error {
	n := trayData(NIF_MESSAGE | NIF_ICON | NIF_TIP)
	r, _, e := pShellNotifyIconW.Call(NIM_ADD, uintptr(unsafe.Pointer(&n)))
	if r == 0 {
		return fmt.Errorf("创建系统托盘图标失败：%v", e)
	}
	trayAdded = true
	return nil
}

func removeTrayIcon() {
	if !trayAdded {
		return
	}
	n := trayData(0)
	pShellNotifyIconW.Call(NIM_DELETE, uintptr(unsafe.Pointer(&n)))
	trayAdded = false
}

func queueBalloon(title, text string, isError bool) {
	balloonMu.Lock()
	pendingTitle, pendingText, pendingError = title, text, isError
	balloonMu.Unlock()
	if trayHwnd != 0 {
		pPostMessageW.Call(trayHwnd, WM_SHOW_BALLOON, 0, 0)
	}
}

func showPendingBalloon() {
	balloonMu.Lock()
	title, text, isError := pendingTitle, pendingText, pendingError
	pendingTitle, pendingText, pendingError = "", "", false
	balloonMu.Unlock()
	if text == "" || !trayAdded {
		return
	}
	n := trayData(NIF_INFO)
	utf16Copy(n.InfoTitle[:], title)
	utf16Copy(n.Info[:], text)
	if isError {
		n.InfoFlags = NIIF_ERROR
	} else {
		n.InfoFlags = NIIF_INFO
	}
	pShellNotifyIconW.Call(NIM_MODIFY, uintptr(unsafe.Pointer(&n)))
}

func runNativeTray(app *App) error {
	trayApp = app
	pSetProcessDPIAware.Call()
	instance, _, _ := pGetModuleHandleW.Call(0)
	className, _ := syscall.UTF16PtrFromString("QAAAirTypeTrayWindowV2")
	cursor, _, _ := pLoadCursorW.Call(0, IDC_ARROW)
	trayIcon, _, _ = pLoadIconW.Call(0, IDI_APPLICATION)
	wc := wndClassEx{
		Size:       uint32(unsafe.Sizeof(wndClassEx{})),
		WndProc:    syscall.NewCallback(trayWindowProc),
		Instance:   instance,
		Cursor:     cursor,
		Background: COLOR_WINDOW + 1,
		ClassName:  className,
		Icon:       trayIcon,
		IconSm:     trayIcon,
	}
	if r, _, e := pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r == 0 {
		return fmt.Errorf("注册托盘窗口失败：%v", e)
	}
	taskbarName, _ := syscall.UTF16PtrFromString("TaskbarCreated")
	r, _, _ := pRegisterWindowMessageW.Call(uintptr(unsafe.Pointer(taskbarName)))
	taskbarMsg = uint32(r)

	title, _ := syscall.UTF16PtrFromString("QAA AirType")
	hwnd, _, e := pCreateWindowExW.Call(
		0,
		uintptr(unsafe.Pointer(className)),
		uintptr(unsafe.Pointer(title)),
		WS_OVERLAPPED,
		0, 0, 0, 0,
		0, 0, instance, 0,
	)
	if hwnd == 0 {
		return fmt.Errorf("创建托盘窗口失败：%v", e)
	}
	trayHwnd = hwnd
	if err := addTrayIcon(); err != nil {
		pDestroyWindow.Call(hwnd)
		return err
	}
	queueBalloon("QAA AirType 已启动", "程序已隐藏到系统托盘。右键托盘图标可复制手机网址或彻底退出。", false)

	var m msg
	for {
		rr, _, e := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(rr) == -1 {
			return fmt.Errorf("托盘消息循环失败：%v", e)
		}
		if rr == 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	return nil
}

func trayWindowProc(hwnd uintptr, message uint32, wParam, lParam uintptr) uintptr {
	if taskbarMsg != 0 && message == taskbarMsg {
		trayAdded = false
		if err := addTrayIcon(); err != nil {
			trayApp.status.Error(err.Error())
		}
		return 0
	}
	switch message {
	case WM_CREATE:
		return 0
	case WM_TRAYICON:
		switch uint32(lParam) {
		case WM_RBUTTONUP:
			showTrayMenu(hwnd)
		case WM_LBUTTONDBLCLK:
			showStatusDialog()
		}
		return 0
	case WM_NETWORK_READY:
		queueBalloon("网络地址已刷新", "已重新扫描局域网地址，可右键托盘图标复制最新地址。", false)
		return 0
	case WM_SHOW_BALLOON:
		showPendingBalloon()
		return 0
	case WM_CLOSE:
		pDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		removeTrayIcon()
		if trayApp != nil {
			trayApp.Stop()
		}
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, uintptr(message), wParam, lParam)
	return r
}

func appendMenu(menu uintptr, flags uint32, id uintptr, text string) {
	var p uintptr
	if text != "" {
		s, _ := syscall.UTF16PtrFromString(text)
		p = uintptr(unsafe.Pointer(s))
	}
	pAppendMenuW.Call(menu, uintptr(flags), id, p)
}

func showTrayMenu(hwnd uintptr) {
	menu, _, _ := pCreatePopupMenu.Call()
	if menu == 0 {
		return
	}
	defer pDestroyMenu.Call(menu)
	appendMenu(menu, MF_STRING, cmdCopyURL, "复制手机网址")
	appendMenu(menu, MF_STRING, cmdShowQR, "显示手机二维码")
	appendMenu(menu, MF_STRING, cmdOpenPage, "在电脑预览手机网页")
	appendMenu(menu, MF_STRING, cmdStatus, "查看运行状态")
	appendMenu(menu, MF_STRING, cmdRefresh, "重新扫描局域网地址")
	appendMenu(menu, MF_SEPARATOR, 0, "")
	appendMenu(menu, MF_STRING, cmdExit, "彻底退出")

	var pt point
	pGetCursorPos.Call(uintptr(unsafe.Pointer(&pt)))
	pSetForegroundWindow.Call(hwnd)
	cmd, _, _ := pTrackPopupMenu.Call(
		menu,
		TPM_RIGHTBUTTON|TPM_RETURNCMD|TPM_NONOTIFY,
		uintptr(pt.X), uintptr(pt.Y), 0, hwnd, 0,
	)
	pPostMessageW.Call(hwnd, WM_NULL, 0, 0)
	handleTrayCommand(int(cmd))
}

func handleTrayCommand(cmd int) {
	switch cmd {
	case cmdCopyURL:
		if err := trayApp.CopyPhoneURL(); err != nil {
			trayApp.status.Error("复制网址失败：" + err.Error())
			queueBalloon("复制失败", err.Error(), true)
		} else {
			trayApp.status.Action("手机网址已复制到剪贴板")
			queueBalloon("已复制手机网址", "请在手机浏览器中粘贴并打开。", false)
		}
	case cmdShowQR:
		if err := trayApp.OpenQRCode(); err != nil {
			trayApp.status.Error(err.Error())
			queueBalloon("二维码打开失败", err.Error(), true)
		}
	case cmdOpenPage:
		if err := trayApp.OpenPreview(); err != nil {
			trayApp.status.Error(err.Error())
			queueBalloon("打开失败", err.Error(), true)
		}
	case cmdStatus:
		showStatusDialog()
	case cmdRefresh:
		trayApp.status.Action("正在后台重新扫描局域网地址")
		go func() {
			trayApp.RefreshNetwork()
			if trayHwnd != 0 {
				pPostMessageW.Call(trayHwnd, WM_NETWORK_READY, 0, 0)
			}
		}()
	case cmdExit:
		pDestroyWindow.Call(trayHwnd)
	}
}

func showStatusDialog() {
	if trayApp == nil {
		return
	}
	addressLines := trayApp.CachedPhoneAddressLines()
	s := trayApp.status.Get()
	lines := []string{
		"QAA AirType " + appVersion,
		"",
		"服务：正在运行（端口 " + fmt.Sprint(trayApp.config.Port) + "）",
	}
	if len(addressLines) == 0 {
		lines = append(lines, "局域网地址：暂未发现，请确认电脑已连接路由器（Wi-Fi 或网线均可）")
	} else {
		lines = append(lines, "可用网卡与手机网址：", strings.Join(addressLines, "\r\n\r\n"))
	}
	if !s.LastPhoneSeen.IsZero() {
		lines = append(lines, "", "手机最近访问："+s.LastPhoneSeen.Format("2006-01-02 15:04:05"))
	} else {
		lines = append(lines, "", "手机最近访问：尚未访问")
	}
	lines = append(lines, "已成功发送："+fmt.Sprint(s.SendCount)+" 条")
	if !s.LastSendAt.IsZero() {
		lines = append(lines, fmt.Sprintf("最近发送：%s（%d 字）", s.LastSendAt.Format("15:04:05"), s.LastChars))
	}
	lines = append(lines, "当前状态："+s.LastAction)
	if s.LastError != "" {
		lines = append(lines, "错误："+s.LastError)
	}
	lines = append(lines, "", "提示：关闭此提示后，先点击电脑上的目标输入框，再在手机上按回车发送。")
	showMessage("QAA AirType 运行状态", strings.Join(lines, "\r\n"), MB_OK|MB_ICONINFORMATION)
}

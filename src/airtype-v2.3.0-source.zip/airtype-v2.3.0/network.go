package main

import (
	"fmt"
	"net"
	"sort"
	"strings"
)

type lanAddress struct {
	IP    string
	Iface string
	Score int
}

func isVirtualInterface(name string) bool {
	lower := strings.ToLower(name)
	for _, bad := range []string{
		"vpn", "tun", "tap", "wintun", "tailscale", "zerotier", "wireguard",
		"vmware", "virtualbox", "hyper-v", "vethernet", "docker", "wsl", "loopback",
	} {
		if strings.Contains(lower, bad) {
			return true
		}
	}
	return false
}

func localLANAddresses() []lanAddress {
	var candidates []lanAddress
	ifaces, err := net.Interfaces()
	if err != nil {
		return nil
	}
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 || isVirtualInterface(iface.Name) {
			continue
		}
		addrs, err := iface.Addrs()
		if err != nil {
			continue
		}
		for _, addr := range addrs {
			var ip net.IP
			switch v := addr.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}
			ip = ip.To4()
			if ip == nil || ip.IsLoopback() || ip.IsUnspecified() || (ip[0] == 169 && ip[1] == 254) {
				continue
			}
			score := privateIPScore(ip)
			if score == 0 {
				continue
			}
			lower := strings.ToLower(iface.Name)
			for _, good := range []string{"wi-fi", "wifi", "wlan", "wireless", "ethernet", "以太网", "无线"} {
				if strings.Contains(lower, good) {
					score += 8
					break
				}
			}
			candidates = append(candidates, lanAddress{IP: ip.String(), Iface: iface.Name, Score: score})
		}
	}
	sort.SliceStable(candidates, func(i, j int) bool {
		if candidates[i].Score != candidates[j].Score {
			return candidates[i].Score > candidates[j].Score
		}
		if candidates[i].Iface != candidates[j].Iface {
			return candidates[i].Iface < candidates[j].Iface
		}
		return candidates[i].IP < candidates[j].IP
	})
	seen := map[string]bool{}
	out := make([]lanAddress, 0, len(candidates))
	for _, c := range candidates {
		if !seen[c.IP] {
			seen[c.IP] = true
			out = append(out, c)
		}
	}
	return out
}

func localLANIPs() []string {
	addrs := localLANAddresses()
	out := make([]string, 0, len(addrs))
	for _, addr := range addrs {
		out = append(out, addr.IP)
	}
	return out
}

func privateIPScore(ip net.IP) int {
	b := ip.To4()
	if b == nil {
		return 0
	}
	switch {
	case b[0] == 192 && b[1] == 168:
		return 100
	case b[0] == 10:
		return 90
	case b[0] == 172 && b[1] >= 16 && b[1] <= 31:
		return 75
	default:
		return 0
	}
}

func phoneURLs(port int, token string, ips []string) []string {
	out := make([]string, 0, len(ips))
	for _, ip := range ips {
		out = append(out, fmt.Sprintf("http://%s:%d/?token=%s", ip, port, token))
	}
	return out
}

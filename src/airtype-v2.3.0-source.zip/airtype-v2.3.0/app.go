package main

import (
	"context"
	"crypto/subtle"
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io"
	"io/fs"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"
)

//go:embed web/*
var webFS embed.FS

type App struct {
	status    *StatusStore
	sender    *Sender
	config    Config
	server    *http.Server
	listener  net.Listener
	phoneHTML []byte
	closeOnce sync.Once

	networkMu sync.RWMutex
	lanAddrs  []lanAddress
}

func NewApp() (*App, error) {
	phoneHTML, err := fs.ReadFile(webFS, "web/phone.html")
	if err != nil {
		return nil, err
	}
	cfg, err := loadOrCreateConfig()
	if err != nil {
		return nil, err
	}
	status := newStatusStore()
	a := &App{
		status:    status,
		config:    cfg,
		phoneHTML: phoneHTML,
	}
	a.sender = newSender(status)
	a.RefreshNetwork()
	return a, nil
}

func (a *App) Start() error {
	mux := http.NewServeMux()
	a.registerRoutes(mux)
	a.server = &http.Server{
		Addr:              fmt.Sprintf("0.0.0.0:%d", a.config.Port),
		Handler:           securityHeaders(mux),
		ReadHeaderTimeout: 8 * time.Second,
		ReadTimeout:       5 * time.Minute,
		WriteTimeout:      15 * time.Minute,
		IdleTimeout:       2 * time.Minute,
		MaxHeaderBytes:    16 * 1024,
	}
	ln, err := net.Listen("tcp", a.server.Addr)
	if err != nil {
		return fmt.Errorf("端口 %d 启动失败。请先彻底退出旧版程序：%w", a.config.Port, err)
	}
	a.listener = ln
	go func() {
		if err := a.server.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
			a.status.Error("网页服务异常：" + err.Error())
		}
	}()
	if len(a.CachedPhoneURLs()) == 0 {
		a.status.Action("服务已启动，但暂未发现局域网 IPv4 地址")
	} else {
		a.status.Action("服务已启动并隐藏到托盘")
	}
	return nil
}

func (a *App) Stop() {
	a.closeOnce.Do(func() {
		if a.server != nil {
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()
			_ = a.server.Shutdown(ctx)
		}
		if a.listener != nil {
			_ = a.listener.Close()
		}
	})
}

func securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("Permissions-Policy", "camera=(), geolocation=()")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'")
		next.ServeHTTP(w, r)
	})
}

func (a *App) authorized(r *http.Request) bool {
	token := r.Header.Get("X-QAA-Token")
	if token == "" {
		token = r.URL.Query().Get("token")
	}
	if len(token) != len(a.config.Token) {
		return false
	}
	return subtle.ConstantTimeCompare([]byte(token), []byte(a.config.Token)) == 1
}

func decodeJSON(w http.ResponseWriter, r *http.Request, maxBytes int64, dst any) error {
	r.Body = http.MaxBytesReader(w, r.Body, maxBytes)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		return err
	}
	if err := dec.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		if err == nil {
			return errors.New("请求只能包含一个 JSON 对象")
		}
		return err
	}
	return nil
}

func (a *App) requireAuth(w http.ResponseWriter, r *http.Request) bool {
	if !a.authorized(r) {
		writeJSON(w, http.StatusForbidden, map[string]any{"success": false, "error": "访问令牌无效，请从电脑托盘重新复制网址"})
		return false
	}
	a.status.MarkPhone()
	return true
}

func isLoopbackRequest(r *http.Request) bool {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		host = r.RemoteAddr
	}
	ip := net.ParseIP(strings.Trim(host, "[]"))
	return ip != nil && ip.IsLoopback()
}

func (a *App) registerRoutes(m *http.ServeMux) {
	m.HandleFunc("/qr.png", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet || !isLoopbackRequest(r) {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		url := a.PrimaryPhoneURL()
		if url == "" {
			http.Error(w, "暂未发现局域网地址", http.StatusServiceUnavailable)
			return
		}
		pngData, err := qrPNG(url, 8, 4)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "image/png")
		_, _ = w.Write(pngData)
	})
	m.HandleFunc("/qr", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet || !isLoopbackRequest(r) {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		url := a.PrimaryPhoneURL()
		if url == "" {
			http.Error(w, "暂未发现局域网地址，请先在托盘中重新扫描局域网地址。", http.StatusServiceUnavailable)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		page := `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>QAA AirType 手机二维码</title><style>body{font-family:"Microsoft YaHei",sans-serif;background:#f4f6f8;margin:0;padding:24px;color:#202124}.card{max-width:560px;margin:auto;background:white;border-radius:18px;padding:26px;text-align:center;box-shadow:0 10px 36px #0002}h1{font-size:24px;margin:0 0 8px}.hint{color:#687078;line-height:1.7}.qr{display:block;width:min(82vw,420px);height:auto;margin:20px auto;border:12px solid white;box-shadow:0 3px 18px #0002}.url{word-break:break-all;background:#f4f7fb;border-radius:10px;padding:12px;text-align:left;font-family:Consolas,monospace}</style></head><body><div class="card"><h1>手机扫码打开 AirType</h1><div class="hint">请使用手机普通扫码功能。电脑和手机需连接同一个路由器；电脑使用网线也可以。</div><img class="qr" src="/qr.png" alt="AirType 二维码"><div class="url">` + html.EscapeString(url) + `</div></div></body></html>`
		_, _ = w.Write([]byte(page))
	})

	m.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		if !a.authorized(r) {
			http.Error(w, "访问地址无效，请从电脑托盘重新复制手机网址。", http.StatusForbidden)
			return
		}
		a.status.MarkPhone()
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		if r.Method == http.MethodHead {
			w.WriteHeader(http.StatusOK)
			return
		}
		page := strings.ReplaceAll(string(a.phoneHTML), "__QAA_TOKEN__", a.config.Token)
		_, _ = w.Write([]byte(page))
	})

	m.HandleFunc("/type", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		if !a.requireAuth(w, r) {
			return
		}
		var p struct {
			Text string `json:"text"`
		}
		if err := decodeJSON(w, r, int64(2*maxTextBytes+64*1024), &p); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{"success": false, "error": "请求内容无效或超过 32MB"})
			return
		}
		if err := a.sender.Send(p.Text); err != nil {
			status := http.StatusInternalServerError
			if errors.Is(err, ErrSendBusy) {
				status = http.StatusConflict
			} else if _, validationErr := validateText(p.Text); validationErr != nil {
				status = http.StatusBadRequest
			}
			writeJSON(w, status, map[string]any{"success": false, "error": err.Error()})
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{"success": true})
	})
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func (a *App) RefreshNetwork() []string {
	addrs := localLANAddresses()
	a.networkMu.Lock()
	a.lanAddrs = append([]lanAddress(nil), addrs...)
	a.networkMu.Unlock()
	return a.CachedPhoneURLs()
}

func (a *App) CachedLANAddresses() []lanAddress {
	a.networkMu.RLock()
	defer a.networkMu.RUnlock()
	return append([]lanAddress(nil), a.lanAddrs...)
}

func (a *App) CachedPhoneURLs() []string {
	addrs := a.CachedLANAddresses()
	ips := make([]string, 0, len(addrs))
	for _, addr := range addrs {
		ips = append(ips, addr.IP)
	}
	return phoneURLs(a.config.Port, a.config.Token, ips)
}

func (a *App) CachedPhoneAddressLines() []string {
	addrs := a.CachedLANAddresses()
	lines := make([]string, 0, len(addrs))
	for _, addr := range addrs {
		lines = append(lines, fmt.Sprintf("%s（%s）\r\n%s", addr.Iface, addr.IP, phoneURLs(a.config.Port, a.config.Token, []string{addr.IP})[0]))
	}
	return lines
}

func (a *App) PrimaryPhoneURL() string {
	urls := a.CachedPhoneURLs()
	if len(urls) > 0 {
		return urls[0]
	}
	return ""
}

func (a *App) PreviewURL() string {
	return fmt.Sprintf("http://127.0.0.1:%d/?token=%s", a.config.Port, a.config.Token)
}

func (a *App) OpenPreview() error   { return openBrowser(a.PreviewURL()) }
func (a *App) QRPreviewURL() string { return fmt.Sprintf("http://127.0.0.1:%d/qr", a.config.Port) }
func (a *App) OpenQRCode() error {
	if a.PrimaryPhoneURL() == "" {
		return errors.New("未发现可供手机访问的局域网地址，请先重新扫描局域网地址")
	}
	return openBrowser(a.QRPreviewURL())
}
func (a *App) CopyPhoneURL() error {
	url := a.PrimaryPhoneURL()
	if url == "" {
		return errors.New("未发现可供手机访问的局域网地址，请确认电脑已连接路由器后手动刷新网络")
	}
	return setClipboardText(url)
}

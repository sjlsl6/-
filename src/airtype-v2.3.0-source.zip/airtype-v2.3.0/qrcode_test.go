package main

import (
	"bytes"
	"testing"
)

func TestQRCodePNG(t *testing.T) {
	url := "http://192.168.1.8:5000/?token=0123456789abcdef0123456789abcdef0123456789abcdef"
	pngData, err := qrPNG(url, 6, 4)
	if err != nil {
		t.Fatal(err)
	}
	if len(pngData) < 100 || !bytes.HasPrefix(pngData, []byte{0x89, 'P', 'N', 'G'}) {
		t.Fatal("invalid PNG")
	}
}

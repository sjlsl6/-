//go:build windows

package main

import (
	"fmt"
	"os/exec"
	"syscall"
	"time"
	"unsafe"
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")

	pRegisterClassExW       = user32.NewProc("RegisterClassExW")
	pCreateWindowExW        = user32.NewProc("CreateWindowExW")
	pDefWindowProcW         = user32.NewProc("DefWindowProcW")
	pGetMessageW            = user32.NewProc("GetMessageW")
	pTranslateMessage       = user32.NewProc("TranslateMessage")
	pDispatchMessageW       = user32.NewProc("DispatchMessageW")
	pPostQuitMessage        = user32.NewProc("PostQuitMessage")
	pDestroyWindow          = user32.NewProc("DestroyWindow")
	pLoadCursorW            = user32.NewProc("LoadCursorW")
	pLoadIconW              = user32.NewProc("LoadIconW")
	pMessageBoxW            = user32.NewProc("MessageBoxW")
	pCreatePopupMenu        = user32.NewProc("CreatePopupMenu")
	pAppendMenuW            = user32.NewProc("AppendMenuW")
	pTrackPopupMenu         = user32.NewProc("TrackPopupMenu")
	pDestroyMenu            = user32.NewProc("DestroyMenu")
	pGetCursorPos           = user32.NewProc("GetCursorPos")
	pSetForegroundWindow    = user32.NewProc("SetForegroundWindow")
	pPostMessageW           = user32.NewProc("PostMessageW")
	pRegisterWindowMessageW = user32.NewProc("RegisterWindowMessageW")
	pRegisterHotKey         = user32.NewProc("RegisterHotKey")
	pUnregisterHotKey       = user32.NewProc("UnregisterHotKey")

	pGetModuleHandleW = kernel32.NewProc("GetModuleHandleW")
	pCreateMutexW     = kernel32.NewProc("CreateMutexW")
	pCloseHandle      = kernel32.NewProc("CloseHandle")
	pGetLastError     = kernel32.NewProc("GetLastError")

	pShellExecuteW    = shell32.NewProc("ShellExecuteW")
	pShellNotifyIconW = shell32.NewProc("Shell_NotifyIconW")
)

const (
	WM_CREATE        = 0x0001
	WM_DESTROY       = 0x0002
	WM_CLOSE         = 0x0010
	WM_NULL          = 0x0000
	WM_HOTKEY        = 0x0312
	WM_LBUTTONDBLCLK = 0x0203
	WM_RBUTTONUP     = 0x0205
	WM_APP           = 0x8000
	WM_TRAYICON      = WM_APP + 1
	WM_REQUEST_EXIT  = WM_APP + 2
	WM_MODE_CHANGED  = WM_APP + 3

	IDC_ARROW       = 32512
	IDI_APPLICATION = 32512
	WS_OVERLAPPED   = 0

	NIM_ADD     = 0
	NIM_MODIFY  = 1
	NIM_DELETE  = 2
	NIF_MESSAGE = 1
	NIF_ICON    = 2
	NIF_TIP     = 4
	NIF_INFO    = 0x10
	NIIF_INFO   = 1
	NIIF_ERROR  = 3

	MF_STRING       = 0
	MF_CHECKED      = 0x0008
	MF_SEPARATOR    = 0x800
	TPM_RIGHTBUTTON = 2
	TPM_RETURNCMD   = 0x100
	TPM_NONOTIFY    = 0x80

	MOD_NOREPEAT = 0x4000
	VK_SUBTRACT  = 0x6D
	VK_ADD       = 0x6B

	ERROR_ALREADY_EXISTS = 183
	SW_SHOWNORMAL        = 1

	cmdSettings   = 1001
	cmdPairQR     = 1002
	cmdConnect    = 1003
	cmdDisconnect = 1004
	cmdStatus     = 1005
	cmdMode1      = 1006
	cmdMode2      = 1007
	cmdMode3      = 1008
	cmdExit       = 1009

	hotkeyMinus = 2001
	hotkeyPlus  = 2002
)

type point struct {
	X int32
	Y int32
}

type msg struct {
	HWnd     uintptr
	Message  uint32
	WParam   uintptr
	LParam   uintptr
	Time     uint32
	Pt       point
	LPrivate uint32
}

type wndClassEx struct {
	Size       uint32
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	Instance   uintptr
	Icon       uintptr
	Cursor     uintptr
	Background uintptr
	MenuName   *uint16
	ClassName  *uint16
	IconSm     uintptr
}

type guid struct {
	D1 uint32
	D2 uint16
	D3 uint16
	D4 [8]byte
}

type notifyIconData struct {
	Size             uint32
	HWnd             uintptr
	ID               uint32
	Flags            uint32
	CallbackMessage  uint32
	Icon             uintptr
	Tip              [128]uint16
	State            uint32
	StateMask        uint32
	Info             [256]uint16
	TimeoutOrVersion uint32
	InfoTitle        [64]uint16
	InfoFlags        uint32
	GUID             guid
	BalloonIcon      uintptr
}

// 这些 Win32 结构体的 x64 大小必须精确，否则托盘或消息循环会出现隐蔽错误。
var _ [80 - unsafe.Sizeof(wndClassEx{})]byte
var _ [unsafe.Sizeof(wndClassEx{}) - 80]byte
var _ [48 - unsafe.Sizeof(msg{})]byte
var _ [unsafe.Sizeof(msg{}) - 48]byte
var _ [976 - unsafe.Sizeof(notifyIconData{})]byte
var _ [unsafe.Sizeof(notifyIconData{}) - 976]byte

var (
	trayHwnd   uintptr
	trayIcon   uintptr
	trayAdded  bool
	taskbarMsg uint32
	trayApp    *App
)

func platformHiddenCommand(name string, args ...string) *exec.Cmd {
	cmd := exec.Command(name, args...)
	applyHiddenWindow(cmd)
	return cmd
}

func applyHiddenWindow(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
}

func acquireSingleInstance() (func(), bool, error) {
	name, _ := syscall.UTF16PtrFromString("Local\\QAA_ADB_TAP_V1_SINGLE_INSTANCE")
	h, _, callErr := pCreateMutexW.Call(0, 0, uintptr(unsafe.Pointer(name)))
	if h == 0 {
		return nil, false, callErr
	}
	last, _, _ := pGetLastError.Call()
	if last == ERROR_ALREADY_EXISTS {
		pCloseHandle.Call(h)
		return nil, true, nil
	}
	return func() { pCloseHandle.Call(h) }, false, nil
}

func messageBox(title, text string, flags uintptr) {
	t, _ := syscall.UTF16PtrFromString(title)
	m, _ := syscall.UTF16PtrFromString(text)
	pMessageBoxW.Call(0, uintptr(unsafe.Pointer(m)), uintptr(unsafe.Pointer(t)), flags|0x00040000)
}

func showError(title, text string) { messageBox(title, text, 0x10) }
func showInfo(title, text string)  { messageBox(title, text, 0x40) }

func openURL(url string) error {
	op, _ := syscall.UTF16PtrFromString("open")
	u, _ := syscall.UTF16PtrFromString(url)
	r, _, callErr := pShellExecuteW.Call(0, uintptr(unsafe.Pointer(op)), uintptr(unsafe.Pointer(u)), 0, 0, SW_SHOWNORMAL)
	if r <= 32 {
		return fmt.Errorf("打开设置页失败：%v", callErr)
	}
	return nil
}

func utf16Copy(dst []uint16, text string) {
	src, _ := syscall.UTF16FromString(text)
	if len(src) > len(dst) {
		src = src[:len(dst)]
		src[len(src)-1] = 0
	}
	copy(dst, src)
}

func trayData(flags uint32) notifyIconData {
	n := notifyIconData{HWnd: trayHwnd, ID: 1, Flags: flags, CallbackMessage: WM_TRAYICON, Icon: trayIcon}
	n.Size = uint32(unsafe.Sizeof(n))
	tip := "QAA ADB Tap - 小键盘加减号点击"
	if trayApp != nil {
		tip = fmt.Sprintf("QAA ADB Tap - 模式 %d", trayApp.config.Get().ActiveMode)
	}
	utf16Copy(n.Tip[:], tip)
	return n
}

func addTray() error {
	n := trayData(NIF_MESSAGE | NIF_ICON | NIF_TIP)
	r, _, callErr := pShellNotifyIconW.Call(NIM_ADD, uintptr(unsafe.Pointer(&n)))
	if r == 0 {
		return fmt.Errorf("创建托盘图标失败：%v", callErr)
	}
	trayAdded = true
	return nil
}

func removeTray() {
	if !trayAdded {
		return
	}
	n := trayData(0)
	pShellNotifyIconW.Call(NIM_DELETE, uintptr(unsafe.Pointer(&n)))
	trayAdded = false
}

func balloon(title, text string, isErr bool) {
	if !trayAdded {
		return
	}
	n := trayData(NIF_INFO)
	utf16Copy(n.InfoTitle[:], title)
	utf16Copy(n.Info[:], text)
	if isErr {
		n.InfoFlags = NIIF_ERROR
	} else {
		n.InfoFlags = NIIF_INFO
	}
	pShellNotifyIconW.Call(NIM_MODIFY, uintptr(unsafe.Pointer(&n)))
}

func notifyModeChanged(mode int) {
	if trayHwnd != 0 {
		pPostMessageW.Call(trayHwnd, WM_MODE_CHANGED, uintptr(mode), 0)
	}
}

func refreshTrayTip() {
	if !trayAdded {
		return
	}
	n := trayData(NIF_TIP)
	pShellNotifyIconW.Call(NIM_MODIFY, uintptr(unsafe.Pointer(&n)))
}

func runNativeTray(app *App) error {
	trayApp = app
	instance, _, _ := pGetModuleHandleW.Call(0)
	className, _ := syscall.UTF16PtrFromString("QAAADBTapTrayV1")
	cursor, _, _ := pLoadCursorW.Call(0, IDC_ARROW)
	trayIcon, _, _ = pLoadIconW.Call(0, IDI_APPLICATION)
	wc := wndClassEx{
		Size:       uint32(unsafe.Sizeof(wndClassEx{})),
		WndProc:    syscall.NewCallback(windowProc),
		Instance:   instance,
		Cursor:     cursor,
		Background: 6,
		ClassName:  className,
		Icon:       trayIcon,
		IconSm:     trayIcon,
	}
	if r, _, callErr := pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r == 0 {
		return fmt.Errorf("注册托盘窗口失败：%v", callErr)
	}
	taskbarName, _ := syscall.UTF16PtrFromString("TaskbarCreated")
	r, _, _ := pRegisterWindowMessageW.Call(uintptr(unsafe.Pointer(taskbarName)))
	taskbarMsg = uint32(r)

	title, _ := syscall.UTF16PtrFromString("QAA ADB Tap")
	hwnd, _, callErr := pCreateWindowExW.Call(
		0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(title)), WS_OVERLAPPED,
		0, 0, 0, 0, 0, 0, instance, 0,
	)
	if hwnd == 0 {
		return fmt.Errorf("创建托盘窗口失败：%v", callErr)
	}
	trayHwnd = hwnd
	if err := addTray(); err != nil {
		return err
	}
	if ok, _, _ := pRegisterHotKey.Call(hwnd, hotkeyMinus, MOD_NOREPEAT, VK_SUBTRACT); ok == 0 {
		removeTray()
		return fmt.Errorf("数字小键盘减号注册失败，可能被其他程序占用")
	}
	if ok, _, _ := pRegisterHotKey.Call(hwnd, hotkeyPlus, MOD_NOREPEAT, VK_ADD); ok == 0 {
		pUnregisterHotKey.Call(hwnd, hotkeyMinus)
		removeTray()
		return fmt.Errorf("数字小键盘加号注册失败，可能被其他程序占用")
	}
	balloon("QAA ADB Tap 已启动", "程序已隐藏到托盘。请在设置页保存坐标并手动连接手机。", false)
	go func() {
		time.Sleep(250 * time.Millisecond)
		_ = openURL(app.SettingsURL())
	}()

	var m msg
	for {
		rr, _, callErr := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(rr) == -1 {
			return fmt.Errorf("托盘消息循环失败：%v", callErr)
		}
		if rr == 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	return nil
}

func windowProc(hwnd uintptr, message uint32, wParam, lParam uintptr) uintptr {
	if taskbarMsg != 0 && message == taskbarMsg {
		trayAdded = false
		_ = addTray()
		return 0
	}
	switch message {
	case WM_CREATE:
		return 0
	case WM_MODE_CHANGED:
		refreshTrayTip()
		balloon("模式已切换", fmt.Sprintf("当前使用模式 %d；ADB 连接保持不变。", int(wParam)), false)
		return 0
	case WM_HOTKEY:
		switch int(wParam) {
		case hotkeyMinus:
			if err := trayApp.TriggerMinus(); err != nil {
				balloon("减号点击失败", err.Error(), true)
			}
		case hotkeyPlus:
			if err := trayApp.TriggerPlus(); err != nil {
				balloon("加号点击失败", err.Error(), true)
			}
		}
		return 0
	case WM_TRAYICON:
		switch uint32(lParam) {
		case WM_RBUTTONUP:
			showMenu(hwnd)
		case WM_LBUTTONDBLCLK:
			_ = openURL(trayApp.SettingsURL())
		}
		return 0
	case WM_REQUEST_EXIT, WM_CLOSE:
		pDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		pUnregisterHotKey.Call(hwnd, hotkeyMinus)
		pUnregisterHotKey.Call(hwnd, hotkeyPlus)
		removeTray()
		if trayApp != nil {
			trayApp.Stop()
		}
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, uintptr(message), wParam, lParam)
	return r
}

func appendMenu(menu uintptr, flags uint32, id uintptr, text string) {
	var ptr uintptr
	if text != "" {
		s, _ := syscall.UTF16PtrFromString(text)
		ptr = uintptr(unsafe.Pointer(s))
	}
	pAppendMenuW.Call(menu, uintptr(flags), id, ptr)
}

func showMenu(hwnd uintptr) {
	menu, _, _ := pCreatePopupMenu.Call()
	if menu == 0 {
		return
	}
	defer pDestroyMenu.Call(menu)
	appendMenu(menu, MF_STRING, cmdSettings, "打开设置")
	appendMenu(menu, MF_STRING, cmdPairQR, "二维码配对手机")
	appendMenu(menu, MF_STRING, cmdConnect, "按已保存地址手动连接")
	appendMenu(menu, MF_STRING, cmdDisconnect, "断开连接")
	appendMenu(menu, MF_STRING, cmdStatus, "查看状态")
	appendMenu(menu, MF_SEPARATOR, 0, "")
	active := trayApp.config.Get().ActiveMode
	flags1, flags2, flags3 := uint32(MF_STRING), uint32(MF_STRING), uint32(MF_STRING)
	if active == 1 {
		flags1 |= MF_CHECKED
	}
	if active == 2 {
		flags2 |= MF_CHECKED
	}
	if active == 3 {
		flags3 |= MF_CHECKED
	}
	appendMenu(menu, flags1, cmdMode1, "使用模式 1")
	appendMenu(menu, flags2, cmdMode2, "使用模式 2")
	appendMenu(menu, flags3, cmdMode3, "使用模式 3")
	appendMenu(menu, MF_SEPARATOR, 0, "")
	appendMenu(menu, MF_STRING, cmdExit, "彻底退出")
	var pt point
	pGetCursorPos.Call(uintptr(unsafe.Pointer(&pt)))
	pSetForegroundWindow.Call(hwnd)
	cmd, _, _ := pTrackPopupMenu.Call(menu, TPM_RIGHTBUTTON|TPM_RETURNCMD|TPM_NONOTIFY, uintptr(pt.X), uintptr(pt.Y), 0, hwnd, 0)
	pPostMessageW.Call(hwnd, WM_NULL, 0, 0)
	handleCommand(int(cmd))
}

func handleCommand(cmd int) {
	switch cmd {
	case cmdSettings:
		_ = openURL(trayApp.SettingsURL())
	case cmdPairQR:
		_ = openURL(trayApp.SettingsURL() + "?pair=1")
	case cmdConnect:
		go func() {
			if err := trayApp.ConnectSaved(); err != nil {
				balloon("连接失败", err.Error(), true)
			} else {
				balloon("连接成功", "小键盘 - 和 + 已就绪。", false)
			}
		}()
	case cmdDisconnect:
		go trayApp.Disconnect()
	case cmdStatus:
		showInfo("QAA ADB Tap 状态", trayApp.StatusText())
	case cmdMode1:
		_, _ = trayApp.SetActiveMode(1)
	case cmdMode2:
		_, _ = trayApp.SetActiveMode(2)
	case cmdMode3:
		_, _ = trayApp.SetActiveMode(3)
	case cmdExit:
		requestAppExit()
	}
}

func requestAppExit() {
	if trayHwnd != 0 {
		pPostMessageW.Call(trayHwnd, WM_REQUEST_EXIT, 0, 0)
	}
}

# QAA ADB Tap v1.1.0 Wireless 源码

这是 `QAA-ADB-Tap-v1.1.0.exe` 对应的完整 Go 源码归档。它面向 Android
无线调试，支持无线 ADB 配对/连接、三套坐标和数字小键盘 `-` / `+` 热键。

Windows 10/11 amd64 用户可安装 Go 1.23.2（或兼容的 Go 1.23 版本），运行
`build_windows.cmd`。脚本会先执行全部测试，再生成 Windows GUI 程序。

已验证正式 EXE 的 SHA-256：

`fd685aba6db35ff8e4a24a5056fac2d7a0cfcf7faccaa89e9d2c5afe3ae871f7`

运行时 `config.json`、设备信息、ADB 地址和配对数据不包含在此源码包中。

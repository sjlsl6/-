//go:build !windows

package main

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestPersistentShellConnectAndTap(t *testing.T) {
	dir := t.TempDir()
	logPath := filepath.Join(dir, "tap.log")
	adbPath := filepath.Join(dir, "adb.exe")
	script := `#!/bin/sh
if [ "$1" = "connect" ]; then echo "connected to $2"; exit 0; fi
if [ "$1" = "disconnect" ]; then echo "disconnected $2"; exit 0; fi
if [ "$1" = "-s" ] && [ "$3" = "get-state" ]; then echo device; exit 0; fi
if [ "$1" = "-s" ] && [ "$3" = "shell" ]; then
  while IFS= read -r line; do
    case "$line" in
      echo\ __QAA_READY_*) echo "${line#echo }" ;;
      *echo\ __QAA_WARM_*) echo "${line##*echo }" ;;
      input\ tap*) echo "$line" >> "$QAA_TEST_TAP_LOG" ;;
    esac
  done
  exit 0
fi
exit 1
`
	if err := os.WriteFile(adbPath, []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"AdbWinApi.dll", "AdbWinUsbApi.dll"} {
		if err := os.WriteFile(filepath.Join(dir, name), []byte("test"), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	oldPath := os.Getenv("PATH")
	oldLog := os.Getenv("QAA_TEST_TAP_LOG")
	t.Cleanup(func() { _ = os.Setenv("PATH", oldPath); _ = os.Setenv("QAA_TEST_TAP_LOG", oldLog) })
	_ = os.Setenv("PATH", dir+string(os.PathListSeparator)+oldPath)
	_ = os.Setenv("QAA_TEST_TAP_LOG", logPath)

	status := newStatusStore()
	a := newADBManager(status)
	t.Cleanup(a.Stop)
	if _, err := a.Connect("127.0.0.1:5555"); err != nil {
		t.Fatal(err)
	}
	if err := a.Trigger(123, 456, "减号"); err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		raw, _ := os.ReadFile(logPath)
		if strings.Contains(string(raw), "input tap 123 456") {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	raw, _ := os.ReadFile(logPath)
	t.Fatalf("tap not observed: %q", raw)
}

func TestQRCodePairingDiscoveryStopsAfterConnectAddress(t *testing.T) {
	dir := t.TempDir()
	statePath := filepath.Join(dir, "paired.state")
	adbPath := filepath.Join(dir, "adb.exe")
	script := `#!/bin/sh
if [ "$1" = "start-server" ]; then exit 0; fi
if [ "$1" = "mdns" ] && [ "$2" = "services" ]; then
  if [ -f "$QAA_PAIR_STATE" ]; then
    echo "adb-phone _adb-tls-connect._tcp 192.168.1.8:45678"
  else
    echo "studio-Test123456 _adb-tls-pairing._tcp 192.168.1.8:41234"
  fi
  exit 0
fi
if [ "$1" = "pair" ]; then
  [ "$2" = "192.168.1.8:41234" ] || exit 2
  [ "$3" = "ABCDEFGH2345" ] || exit 3
  touch "$QAA_PAIR_STATE"
  echo "Successfully paired to $2"
  exit 0
fi
exit 1
`
	if err := os.WriteFile(adbPath, []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"AdbWinApi.dll", "AdbWinUsbApi.dll"} {
		if err := os.WriteFile(filepath.Join(dir, name), []byte("test"), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	oldPath, oldState := os.Getenv("PATH"), os.Getenv("QAA_PAIR_STATE")
	t.Cleanup(func() { _ = os.Setenv("PATH", oldPath); _ = os.Setenv("QAA_PAIR_STATE", oldState) })
	_ = os.Setenv("PATH", dir+string(os.PathListSeparator)+oldPath)
	_ = os.Setenv("QAA_PAIR_STATE", statePath)
	a := newADBManager(newStatusStore())
	t.Cleanup(a.Stop)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	address, err := a.PairByQRCode(ctx, "studio-Test123456", "ABCDEFGH2345", nil)
	if err != nil {
		t.Fatal(err)
	}
	if address != "192.168.1.8:45678" {
		t.Fatalf("address=%s", address)
	}
}

func TestFullQRCodePairingSavesAddressAndStartsPersistentShell(t *testing.T) {
	dir := t.TempDir()
	servicePath := filepath.Join(dir, "service.txt")
	pairedPath := filepath.Join(dir, "paired.state")
	adbPath := filepath.Join(dir, "adb.exe")
	script := `#!/bin/sh
if [ "$1" = "start-server" ]; then exit 0; fi
if [ "$1" = "mdns" ] && [ "$2" = "services" ]; then
  if [ -f "$QAA_FULL_PAIRED" ]; then
    echo "adb-phone _adb-tls-connect._tcp 192.168.1.9:45679"
  elif [ -f "$QAA_FULL_SERVICE" ]; then
    svc=$(cat "$QAA_FULL_SERVICE")
    echo "$svc _adb-tls-pairing._tcp 192.168.1.9:41235"
  fi
  exit 0
fi
if [ "$1" = "pair" ]; then touch "$QAA_FULL_PAIRED"; echo "Successfully paired to $2"; exit 0; fi
if [ "$1" = "connect" ]; then echo "connected to $2"; exit 0; fi
if [ "$1" = "disconnect" ]; then exit 0; fi
if [ "$1" = "-s" ] && [ "$3" = "get-state" ]; then echo device; exit 0; fi
if [ "$1" = "-s" ] && [ "$3" = "shell" ]; then
  while IFS= read -r line; do
    case "$line" in
      echo\ __QAA_READY_*) echo "${line#echo }" ;;
      *echo\ __QAA_WARM_*) echo "${line##*echo }" ;;
    esac
  done
  exit 0
fi
exit 1
`
	if err := os.WriteFile(adbPath, []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"AdbWinApi.dll", "AdbWinUsbApi.dll"} {
		if err := os.WriteFile(filepath.Join(dir, name), []byte("test"), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	oldPath := os.Getenv("PATH")
	oldService := os.Getenv("QAA_FULL_SERVICE")
	oldPaired := os.Getenv("QAA_FULL_PAIRED")
	t.Cleanup(func() {
		_ = os.Setenv("PATH", oldPath)
		_ = os.Setenv("QAA_FULL_SERVICE", oldService)
		_ = os.Setenv("QAA_FULL_PAIRED", oldPaired)
	})
	_ = os.Setenv("PATH", dir+string(os.PathListSeparator)+oldPath)
	_ = os.Setenv("QAA_FULL_SERVICE", servicePath)
	_ = os.Setenv("QAA_FULL_PAIRED", pairedPath)
	cfg := &ConfigStore{path: filepath.Join(dir, "config.json"), data: defaultConfig()}
	status := newStatusStore()
	adb := newADBManager(status)
	t.Cleanup(adb.Stop)
	pm := newPairingManager(adb, cfg, status)
	state, err := pm.Start()
	if err != nil {
		t.Fatal(err)
	}
	payload, ok := pm.QRPayload(state.ID)
	if !ok {
		t.Fatal("missing payload")
	}
	start := strings.Index(payload, "S:")
	end := strings.Index(payload[start:], ";P:")
	if start < 0 || end < 0 {
		t.Fatalf("bad payload: %s", payload)
	}
	service := payload[start+2 : start+end]
	if err := os.WriteFile(servicePath, []byte(service), 0o600); err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		ps := pm.State()
		if !ps.Active && ps.Address != "" {
			if ps.Error != "" {
				t.Fatal(ps.Error)
			}
			if ps.Address != "192.168.1.9:45679" {
				t.Fatalf("address=%s", ps.Address)
			}
			if cfg.Get().Address != ps.Address {
				t.Fatal("address was not saved")
			}
			if !status.Get().Connected {
				t.Fatal("persistent shell not connected")
			}
			return
		}
		time.Sleep(20 * time.Millisecond)
	}
	t.Fatalf("pairing did not finish: %#v", pm.State())
}

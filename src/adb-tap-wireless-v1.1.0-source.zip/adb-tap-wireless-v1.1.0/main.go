package main

import "runtime"

const appVersion = "1.1.0"

var globalApp *App

func main() {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	release, already, err := acquireSingleInstance()
	if err != nil {
		showError("QAA ADB Tap", err.Error())
		return
	}
	if already {
		showInfo("QAA ADB Tap", "程序已经在系统托盘运行，请查看任务栏右下角。")
		return
	}
	if release != nil {
		defer release()
	}
	app, err := NewApp()
	if err != nil {
		showError("启动失败", err.Error())
		return
	}
	globalApp = app
	if err := app.Start(); err != nil {
		showError("启动失败", err.Error())
		return
	}
	defer app.Stop()
	if err := runNativeTray(app); err != nil {
		showError("程序异常", err.Error())
	}
}

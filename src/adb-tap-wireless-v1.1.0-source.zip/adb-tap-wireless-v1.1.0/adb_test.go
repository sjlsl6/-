package main

import (
	"testing"
	"time"
)

func TestTapQueueDoesNotGrowWithoutBound(t *testing.T) {
	a := &ADBManager{requests: make(chan tapRequest, 2)}
	a.requests <- tapRequest{}
	a.requests <- tapRequest{}
	select {
	case a.requests <- tapRequest{}:
		t.Fatal("queue unexpectedly accepted third request")
	default:
	}
	if len(a.requests) != 2 {
		t.Fatal("wrong queue length")
	}
	_ = time.Second
}
func TestOutputLooksFailed(t *testing.T) {
	for _, s := range []string{"failed to connect", "device offline", "connection refused"} {
		if !outputLooksFailed(s) {
			t.Fatalf("not detected: %s", s)
		}
	}
	if outputLooksFailed("connected to 1.2.3.4:5555") {
		t.Fatal("success classified as failure")
	}
}

func TestParseMDNSServices(t *testing.T) {
	out := "List of discovered mdns services\nstudio-ABC123 _adb-tls-pairing._tcp 192.168.1.8:41234\nadb-phone _adb-tls-connect._tcp 192.168.1.8:45678\nnoise line"
	recs := parseMDNSServices(out)
	if len(recs) != 2 || recs[0].Instance != "studio-ABC123" || recs[1].Address != "192.168.1.8:45678" {
		t.Fatalf("unexpected records: %#v", recs)
	}
	if !sameAddressHost(recs[0].Address, recs[1].Address) {
		t.Fatal("same host was not recognized")
	}
}

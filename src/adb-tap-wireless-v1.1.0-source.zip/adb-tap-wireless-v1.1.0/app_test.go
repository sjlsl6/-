package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func testADBApp(t *testing.T) *App {
	t.Helper()
	t.Setenv("APPDATA", t.TempDir())
	a, err := NewApp()
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(a.Stop)
	return a
}

func adbJSONRequest(m http.Handler, method, path string, value any) *httptest.ResponseRecorder {
	var body bytes.Buffer
	if value != nil {
		_ = json.NewEncoder(&body).Encode(value)
	}
	req := httptest.NewRequest(method, path, &body)
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	m.ServeHTTP(w, req)
	return w
}

func TestSettingsPageContainsQRCodeAndThreeModes(t *testing.T) {
	a := testADBApp(t)
	mux := http.NewServeMux()
	a.routes(mux)
	w := adbJSONRequest(mux, http.MethodGet, "/", nil)
	if w.Code != 200 {
		t.Fatalf("status=%d", w.Code)
	}
	page := w.Body.String()
	for _, want := range []string{"生成二维码配对", "模式 1", "模式 2", "模式 3", "m${n}MinusX", "m${n}PlusY"} {
		if !strings.Contains(page, want) {
			t.Fatalf("missing %q", want)
		}
	}
}

func TestSaveThreeModesAndSwitch(t *testing.T) {
	a := testADBApp(t)
	mux := http.NewServeMux()
	a.routes(mux)
	cfg := defaultConfig()
	cfg.ActiveMode = 2
	cfg.Modes[1] = TapMode{MinusX: 11, MinusY: 22, PlusX: 33, PlusY: 44}
	w := adbJSONRequest(mux, http.MethodPost, "/api/save", cfg)
	if w.Code != 200 {
		t.Fatalf("save=%d %s", w.Code, w.Body.String())
	}
	if got := a.config.Get(); got.ActiveMode != 2 || got.CurrentMode().PlusY != 44 {
		t.Fatalf("got=%#v", got)
	}
	w = adbJSONRequest(mux, http.MethodPost, "/api/mode", map[string]any{"mode": 3})
	if w.Code != 200 || a.config.Get().ActiveMode != 3 {
		t.Fatalf("mode=%d %s", w.Code, w.Body.String())
	}
}

func TestPairingQRCodeEndpoint(t *testing.T) {
	a := testADBApp(t)
	mux := http.NewServeMux()
	a.routes(mux)
	a.pairing.mu.Lock()
	a.pairing.state = PairingState{ID: "test-session", Active: true}
	a.pairing.payload = "WIFI:T:ADB;S:studio-AbCd234567;P:ABCDEFGH2345;;"
	a.pairing.mu.Unlock()
	w := adbJSONRequest(mux, http.MethodGet, "/api/pair/qr.png?id=test-session", nil)
	if w.Code != 200 || w.Header().Get("Content-Type") != "image/png" || !bytes.HasPrefix(w.Body.Bytes(), []byte{0x89, 'P', 'N', 'G'}) {
		t.Fatalf("status=%d type=%s", w.Code, w.Header().Get("Content-Type"))
	}
	w = adbJSONRequest(mux, http.MethodGet, "/api/pair/qr.png?id=wrong", nil)
	if w.Code != http.StatusNotFound {
		t.Fatalf("wrong id status=%d", w.Code)
	}
}

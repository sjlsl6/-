package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestValidateAddress(t *testing.T) {
	good := []string{"192.168.1.2:37123", "adb-ABC._adb-tls-connect._tcp:12345", "[fe80::1]:5555"}
	for _, v := range good {
		if err := validateAddress(v); err != nil {
			t.Fatalf("%s: %v", v, err)
		}
	}
	bad := []string{"", "192.168.1.2", "[fe80::1]", "1.2.3.4:99999", "1.2.3.4:22;rm"}
	for _, v := range bad {
		if validateAddress(v) == nil {
			t.Fatalf("expected invalid: %s", v)
		}
	}
}
func TestCoordinates(t *testing.T) {
	if validCoordinate(0, 0) {
		t.Fatal("zero coordinate must be unset")
	}
	if !validCoordinate(0, 100) {
		t.Fatal("edge coordinate should be allowed")
	}
}

func TestConfigSaveReplacesExistingFile(t *testing.T) {
	dir := t.TempDir()
	s := &ConfigStore{path: filepath.Join(dir, "config.json"), data: Config{Version: 1, Address: "127.0.0.1:5555"}}
	if err := os.WriteFile(s.path, []byte("old"), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := s.saveLocked(); err != nil {
		t.Fatal(err)
	}
	raw, err := os.ReadFile(s.path)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(raw), "127.0.0.1:5555") {
		t.Fatalf("unexpected config: %s", raw)
	}
}

func TestThreeModesAndActiveMode(t *testing.T) {
	dir := t.TempDir()
	s := &ConfigStore{path: filepath.Join(dir, "config.json"), data: defaultConfig()}
	cfg := defaultConfig()
	cfg.Address = "127.0.0.1:5555"
	cfg.ActiveMode = 3
	cfg.Modes[2] = TapMode{MinusX: 10, MinusY: 20, PlusX: 30, PlusY: 40}
	got, err := s.Update(cfg)
	if err != nil {
		t.Fatal(err)
	}
	if got.ActiveMode != 3 || got.CurrentMode().PlusY != 40 || len(got.Modes) != 3 {
		t.Fatalf("unexpected config: %#v", got)
	}
	if _, err := s.SetActiveMode(2); err != nil {
		t.Fatal(err)
	}
	if s.Get().ActiveMode != 2 {
		t.Fatal("mode did not switch")
	}
}

func TestLegacyConfigMigratesIntoModeOne(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("APPDATA", dir)
	appDir := filepath.Join(dir, "QAA-ADB-Tap")
	if err := os.MkdirAll(appDir, 0o755); err != nil {
		t.Fatal(err)
	}
	legacy := `{"version":1,"address":"127.0.0.1:5555","minusX":11,"minusY":22,"plusX":33,"plusY":44}`
	if err := os.WriteFile(filepath.Join(appDir, "config.json"), []byte(legacy), 0o600); err != nil {
		t.Fatal(err)
	}
	s, err := newConfigStore()
	if err != nil {
		t.Fatal(err)
	}
	cfg := s.Get()
	if cfg.Version != 2 || cfg.ActiveMode != 1 || cfg.Modes[0].MinusX != 11 || cfg.Modes[0].PlusY != 44 {
		t.Fatalf("migration failed: %#v", cfg)
	}
}

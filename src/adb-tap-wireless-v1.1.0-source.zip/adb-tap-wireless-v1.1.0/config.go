package main

import (
	"encoding/json"
	"errors"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
)

type TapMode struct {
	MinusX int `json:"minusX"`
	MinusY int `json:"minusY"`
	PlusX  int `json:"plusX"`
	PlusY  int `json:"plusY"`
}

type Config struct {
	Version    int       `json:"version"`
	Address    string    `json:"address"`
	ActiveMode int       `json:"activeMode"`
	Modes      []TapMode `json:"modes"`
}

type legacyConfig struct {
	Version int    `json:"version"`
	Address string `json:"address"`
	MinusX  int    `json:"minusX"`
	MinusY  int    `json:"minusY"`
	PlusX   int    `json:"plusX"`
	PlusY   int    `json:"plusY"`
}

type ConfigStore struct {
	mu   sync.RWMutex
	path string
	data Config
}

func configDirectory() (string, error) {
	appData := strings.TrimSpace(os.Getenv("APPDATA"))
	if appData == "" {
		return "", errors.New("无法读取 Windows APPDATA 目录")
	}
	dir := filepath.Join(appData, "QAA-ADB-Tap")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	return dir, nil
}

func defaultConfig() Config {
	return Config{Version: 2, ActiveMode: 1, Modes: make([]TapMode, 3)}
}

func newConfigStore() (*ConfigStore, error) {
	dir, err := configDirectory()
	if err != nil {
		return nil, err
	}
	s := &ConfigStore{path: filepath.Join(dir, "config.json"), data: defaultConfig()}
	if raw, err := os.ReadFile(s.path); err == nil {
		var next Config
		if json.Unmarshal(raw, &next) == nil && len(next.Modes) > 0 {
			s.data = next
		} else {
			var old legacyConfig
			if json.Unmarshal(raw, &old) == nil {
				s.data.Address = old.Address
				s.data.Modes[0] = TapMode{MinusX: old.MinusX, MinusY: old.MinusY, PlusX: old.PlusX, PlusY: old.PlusY}
			}
		}
	}
	s.normalizeLocked()
	if err := s.saveLocked(); err != nil {
		return nil, err
	}
	return s, nil
}

func normalizeMode(m TapMode) TapMode {
	if m.MinusX < 0 {
		m.MinusX = 0
	}
	if m.MinusY < 0 {
		m.MinusY = 0
	}
	if m.PlusX < 0 {
		m.PlusX = 0
	}
	if m.PlusY < 0 {
		m.PlusY = 0
	}
	return m
}

func (s *ConfigStore) normalizeLocked() {
	s.data.Version = 2
	s.data.Address = strings.TrimSpace(s.data.Address)
	if s.data.ActiveMode < 1 || s.data.ActiveMode > 3 {
		s.data.ActiveMode = 1
	}
	modes := make([]TapMode, 3)
	copy(modes, s.data.Modes)
	for i := range modes {
		modes[i] = normalizeMode(modes[i])
	}
	s.data.Modes = modes
}

func (s *ConfigStore) saveLocked() error {
	raw, err := json.MarshalIndent(s.data, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, raw, 0o600); err != nil {
		return err
	}
	if err := os.Rename(tmp, s.path); err == nil {
		return nil
	}
	if err := os.Remove(s.path); err != nil && !os.IsNotExist(err) {
		return err
	}
	return os.Rename(tmp, s.path)
}

func (s *ConfigStore) Get() Config {
	s.mu.RLock()
	defer s.mu.RUnlock()
	c := s.data
	c.Modes = append([]TapMode(nil), s.data.Modes...)
	return c
}

func (s *ConfigStore) ActiveTapMode() (int, TapMode) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	mode := s.data.ActiveMode
	idx := mode - 1
	if idx < 0 || idx >= len(s.data.Modes) {
		return 1, TapMode{}
	}
	return mode, s.data.Modes[idx]
}

func (s *ConfigStore) Update(c Config) (Config, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	previous := s.data
	s.data = c
	s.normalizeLocked()
	if s.data.Address != "" {
		if err := validateAddress(s.data.Address); err != nil {
			s.data = previous
			return Config{}, err
		}
	}
	if err := s.saveLocked(); err != nil {
		s.data = previous
		return Config{}, err
	}
	out := s.data
	out.Modes = append([]TapMode(nil), s.data.Modes...)
	return out, nil
}

func (s *ConfigStore) SetAddress(address string) (Config, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	address = strings.TrimSpace(address)
	if err := validateAddress(address); err != nil {
		return Config{}, err
	}
	previous := s.data
	s.data.Address = address
	s.normalizeLocked()
	if err := s.saveLocked(); err != nil {
		s.data = previous
		return Config{}, err
	}
	out := s.data
	out.Modes = append([]TapMode(nil), s.data.Modes...)
	return out, nil
}

func (s *ConfigStore) SetActiveMode(mode int) (Config, error) {
	if mode < 1 || mode > 3 {
		return Config{}, errors.New("模式必须是 1、2 或 3")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	previous := s.data
	s.data.ActiveMode = mode
	if err := s.saveLocked(); err != nil {
		s.data = previous
		return Config{}, err
	}
	out := s.data
	out.Modes = append([]TapMode(nil), s.data.Modes...)
	return out, nil
}

func (c Config) CurrentMode() TapMode {
	idx := c.ActiveMode - 1
	if idx < 0 || idx >= len(c.Modes) {
		return TapMode{}
	}
	return c.Modes[idx]
}

func validateAddress(address string) error {
	address = strings.TrimSpace(address)
	if address == "" {
		return errors.New("请填写无线 ADB 连接地址，例如 192.168.1.20:37123")
	}
	if strings.ContainsAny(address, " \t\r\n;&|<>") {
		return errors.New("ADB 地址包含不允许的字符")
	}
	host, portText, err := net.SplitHostPort(address)
	if err != nil || strings.TrimSpace(host) == "" {
		return errors.New("ADB 地址必须包含有效端口，例如 192.168.1.20:37123")
	}
	p, err := strconv.Atoi(portText)
	if err != nil || p < 1 || p > 65535 {
		return errors.New("ADB 端口无效")
	}
	return nil
}

func validCoordinate(x, y int) bool { return x >= 0 && y >= 0 && (x != 0 || y != 0) }

package main

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type tapRequest struct {
	x, y  int
	label string
}

type ADBManager struct {
	status     *StatusStore
	mu         sync.Mutex
	writeMu    sync.Mutex
	connectMu  sync.Mutex
	adbPath    string
	serial     string
	shell      *exec.Cmd
	stdin      io.WriteCloser
	stdout     io.ReadCloser
	stopping   bool
	requests   chan tapRequest
	stopWorker chan struct{}
	workerDone chan struct{}
}

func newADBManager(status *StatusStore) *ADBManager {
	a := &ADBManager{status: status, requests: make(chan tapRequest, 2), stopWorker: make(chan struct{}), workerDone: make(chan struct{})}
	go a.worker()
	return a
}

func executableDir() (string, error) {
	exe, err := os.Executable()
	if err != nil {
		return "", err
	}
	return filepath.Dir(exe), nil
}

func (a *ADBManager) findADB() (string, error) {
	dir, err := executableDir()
	if err != nil {
		return "", err
	}
	candidates := []string{
		filepath.Join(dir, "platform-tools", "adb.exe"),
		filepath.Join(dir, "adb.exe"),
	}
	if cfgDir, cfgErr := configDirectory(); cfgErr == nil {
		candidates = append(candidates, filepath.Join(cfgDir, "platform-tools", "adb.exe"))
	}
	if appData := strings.TrimSpace(os.Getenv("APPDATA")); appData != "" {
		// 兼容用户此前使用过的 QAA 版本，优先复用已经下载好的 ADB。
		candidates = append(candidates,
			filepath.Join(appData, "QAA-AirType-Voice-v2", "platform-tools", "adb.exe"),
			filepath.Join(appData, "QAA-AirType-Keyboard-v23", "platform-tools", "adb.exe"),
		)
	}
	for _, p := range candidates {
		if validADBExecutable(p) {
			return p, nil
		}
	}
	if p, err := exec.LookPath("adb.exe"); err == nil && validADBExecutable(p) {
		return p, nil
	}
	return "", errors.New("未找到可用的 ADB，请在设置页点击“一次性准备 ADB”")
}

func validADBExecutable(path string) bool {
	st, err := os.Stat(path)
	if err != nil || st.IsDir() {
		return false
	}
	dir := filepath.Dir(path)
	for _, name := range []string{"AdbWinApi.dll", "AdbWinUsbApi.dll"} {
		if info, err := os.Stat(filepath.Join(dir, name)); err != nil || info.IsDir() {
			return false
		}
	}
	return true
}

func hiddenCommand(name string, args ...string) *exec.Cmd {
	return platformHiddenCommand(name, args...)
}

func runOutput(timeout time.Duration, name string, args ...string) (string, int, error) {
	return runOutputContext(context.Background(), timeout, name, args...)
}

func runOutputContext(parent context.Context, timeout time.Duration, name string, args ...string) (string, int, error) {
	ctx, cancel := context.WithTimeout(parent, timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, name, args...)
	applyHiddenWindow(cmd)
	raw, err := cmd.CombinedOutput()
	out := strings.TrimSpace(string(raw))
	if parentErr := parent.Err(); parentErr != nil {
		return out, -1, parentErr
	}
	if ctx.Err() == context.DeadlineExceeded {
		return out, -1, errors.New("操作超时")
	}
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			return out, ee.ExitCode(), err
		}
		return out, -1, err
	}
	return out, 0, nil
}

func outputLooksFailed(out string) bool {
	v := strings.ToLower(out)
	for _, word := range []string{"failed", "cannot", "unable", "offline", "unauthorized", "refused", "timed out", "no route"} {
		if strings.Contains(v, word) {
			return true
		}
	}
	return false
}

func (a *ADBManager) Connect(address string) (string, error) {
	a.connectMu.Lock()
	defer a.connectMu.Unlock()
	if err := validateAddress(address); err != nil {
		return "", err
	}
	adb, err := a.findADB()
	if err != nil {
		return "", err
	}
	a.disconnectLocked(false)

	out, rc, runErr := runOutput(15*time.Second, adb, "connect", address)
	if runErr != nil || rc != 0 || outputLooksFailed(out) {
		if out == "" && runErr != nil {
			out = runErr.Error()
		}
		return "", fmt.Errorf("无线 ADB 连接失败：%s", out)
	}
	state, rc, runErr := runOutput(6*time.Second, adb, "-s", address, "get-state")
	if runErr != nil || rc != 0 || strings.TrimSpace(state) != "device" {
		return "", fmt.Errorf("手机未进入可用状态：%s", strings.TrimSpace(state))
	}
	if err := a.startShell(adb, address); err != nil {
		return "", err
	}
	a.status.Connection(true, address)
	a.status.Action("连接成功；数字小键盘 - 和 + 已就绪")
	return out, nil
}

func (a *ADBManager) startShell(adb, serial string) error {
	cmd := hiddenCommand(adb, "-s", serial, "shell")
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return err
	}
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		_ = stdin.Close()
		return err
	}
	cmd.Stderr = cmd.Stdout
	if err := cmd.Start(); err != nil {
		_ = stdin.Close()
		_ = stdout.Close()
		return fmt.Errorf("常驻 ADB Shell 启动失败：%w", err)
	}

	lines := make(chan string, 64)
	go func() {
		scanner := bufio.NewScanner(stdout)
		buf := make([]byte, 0, 64*1024)
		scanner.Buffer(buf, 1024*1024)
		for scanner.Scan() {
			select {
			case lines <- strings.TrimSpace(scanner.Text()):
			default:
			}
		}
		close(lines)
		_ = cmd.Wait()
		a.mu.Lock()
		current := a.shell == cmd
		if current {
			a.shell = nil
			a.stdin = nil
			a.stdout = nil
			a.serial = ""
		}
		stopping := a.stopping
		a.mu.Unlock()
		if current && !stopping {
			a.status.Connection(false, "")
			a.status.Error("常驻 ADB Shell 已断开，请手动重新连接")
		}
	}()

	readyToken := fmt.Sprintf("__QAA_READY_%d__", time.Now().UnixNano())
	if _, err := io.WriteString(stdin, "echo "+readyToken+"\n"); err != nil {
		_ = cmd.Process.Kill()
		return err
	}
	if err := waitToken(lines, readyToken, 5*time.Second); err != nil {
		_ = cmd.Process.Kill()
		return errors.New("ADB Shell 未能完成准备，请重新连接")
	}

	warmToken := fmt.Sprintf("__QAA_WARM_%d__", time.Now().UnixNano())
	// 只预热 Android 的 input 命令，不产生触摸，不改变手机界面。
	if _, err := io.WriteString(stdin, "input --help >/dev/null 2>&1; echo "+warmToken+"\n"); err != nil {
		_ = cmd.Process.Kill()
		return err
	}
	if err := waitToken(lines, warmToken, 6*time.Second); err != nil {
		_ = cmd.Process.Kill()
		return errors.New("手机点击命令预热失败，请重新连接")
	}

	a.mu.Lock()
	a.stopping = false
	a.adbPath = adb
	a.serial = serial
	a.shell = cmd
	a.stdin = stdin
	a.stdout = stdout
	a.mu.Unlock()
	return nil
}

func waitToken(lines <-chan string, token string, timeout time.Duration) error {
	timer := time.NewTimer(timeout)
	defer timer.Stop()
	for {
		select {
		case line, ok := <-lines:
			if !ok {
				return io.EOF
			}
			if line == token {
				return nil
			}
		case <-timer.C:
			return context.DeadlineExceeded
		}
	}
}

func (a *ADBManager) Trigger(x, y int, label string) error {
	if !validCoordinate(x, y) {
		return fmt.Errorf("%s坐标尚未设置", label)
	}
	a.mu.Lock()
	connected := a.shell != nil && a.stdin != nil && a.shell.ProcessState == nil
	a.mu.Unlock()
	if !connected {
		return errors.New("手机尚未连接，请打开设置页手动连接")
	}
	req := tapRequest{x: x, y: y, label: label}
	select {
	case a.requests <- req:
		return nil
	default:
		return errors.New("上一条点击仍在发送，本次按键已丢弃，未形成积压")
	}
}

func (a *ADBManager) worker() {
	defer close(a.workerDone)
	for {
		select {
		case req := <-a.requests:
			a.status.SetBusy(true)
			err := a.writeTap(req)
			a.status.SetBusy(false)
			if err != nil {
				a.status.Error(err.Error())
			} else {
				a.status.Action(fmt.Sprintf("已发送%s点击：(%d, %d)", req.label, req.x, req.y))
			}
		case <-a.stopWorker:
			return
		}
	}
}

func (a *ADBManager) writeTap(req tapRequest) error {
	a.writeMu.Lock()
	defer a.writeMu.Unlock()

	a.mu.Lock()
	cmd, stdin := a.shell, a.stdin
	connected := cmd != nil && stdin != nil && cmd.ProcessState == nil
	a.mu.Unlock()
	if !connected {
		return errors.New("ADB 点击通道不可用，请手动重新连接")
	}
	_, err := io.WriteString(stdin, fmt.Sprintf("input tap %d %d\n", req.x, req.y))
	if err == nil {
		return nil
	}

	// 只清理发生写入错误的那一代 Shell，避免误伤刚刚建立的新连接。
	a.mu.Lock()
	if a.shell == cmd && a.stdin == stdin {
		a.shell = nil
		a.stdin = nil
		a.stdout = nil
		a.serial = ""
	}
	a.mu.Unlock()
	a.status.Connection(false, "")
	return errors.New("ADB 点击通道已断开，请手动重新连接")
}

func (a *ADBManager) Disconnect() {
	a.connectMu.Lock()
	defer a.connectMu.Unlock()
	a.disconnectLocked(true)
	a.status.Action("已手动断开；不会自动重新连接")
}

func (a *ADBManager) disconnectLocked(runADBDisconnect bool) {
	a.mu.Lock()
	a.stopping = true
	cmd, stdin, stdout, adb, serial := a.shell, a.stdin, a.stdout, a.adbPath, a.serial
	a.shell = nil
	a.stdin = nil
	a.stdout = nil
	a.serial = ""
	a.mu.Unlock()
	if stdin != nil {
		_ = stdin.Close()
	}
	if stdout != nil {
		_ = stdout.Close()
	}
	if cmd != nil && cmd.Process != nil {
		_ = cmd.Process.Kill()
	}
	for {
		select {
		case <-a.requests:
		default:
			goto drained
		}
	}
drained:
	if runADBDisconnect && adb != "" && serial != "" {
		_, _, _ = runOutput(4*time.Second, adb, "disconnect", serial)
	}
	a.status.Connection(false, "")
	a.mu.Lock()
	a.stopping = false
	a.mu.Unlock()
}

type mdnsRecord struct {
	Instance string
	Service  string
	Address  string
}

func parseMDNSServices(output string) []mdnsRecord {
	var records []mdnsRecord
	for _, line := range strings.Split(output, "\n") {
		fields := strings.Fields(strings.TrimSpace(line))
		if len(fields) < 3 || !strings.HasPrefix(fields[1], "_adb-") {
			continue
		}
		if validateAddress(fields[2]) != nil {
			continue
		}
		records = append(records, mdnsRecord{Instance: fields[0], Service: fields[1], Address: fields[2]})
	}
	return records
}

func sameAddressHost(a, b string) bool {
	ha, _, ea := net.SplitHostPort(a)
	hb, _, eb := net.SplitHostPort(b)
	return ea == nil && eb == nil && strings.EqualFold(strings.Trim(ha, "[]"), strings.Trim(hb, "[]"))
}

func waitContext(ctx context.Context, d time.Duration) error {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-t.C:
		return nil
	}
}

// PairByQRCode performs discovery only for this explicitly-started QR pairing
// session. It stops immediately after success, cancellation, or timeout.
func (a *ADBManager) PairByQRCode(ctx context.Context, serviceName, password string, onStatus func(string)) (string, error) {
	adb, err := a.findADB()
	if err != nil {
		return "", err
	}
	if onStatus != nil {
		onStatus("正在启动 ADB 配对服务……")
	}
	if out, rc, runErr := runOutputContext(ctx, 10*time.Second, adb, "start-server"); runErr != nil || rc != 0 || outputLooksFailed(out) {
		if errors.Is(runErr, context.Canceled) || errors.Is(runErr, context.DeadlineExceeded) {
			return "", runErr
		}
		if out == "" && runErr != nil {
			out = runErr.Error()
		}
		return "", fmt.Errorf("ADB 服务启动失败：%s", out)
	}

	var pairAddr string
	if onStatus != nil {
		onStatus("等待手机扫描二维码……")
	}
	for pairAddr == "" {
		if err := ctx.Err(); err != nil {
			return "", err
		}
		out, _, _ := runOutputContext(ctx, 5*time.Second, adb, "mdns", "services")
		for _, rec := range parseMDNSServices(out) {
			if rec.Instance == serviceName && rec.Service == "_adb-tls-pairing._tcp" {
				pairAddr = rec.Address
				break
			}
		}
		if pairAddr == "" {
			if err := waitContext(ctx, 900*time.Millisecond); err != nil {
				return "", err
			}
		}
	}

	if onStatus != nil {
		onStatus("已发现手机，正在完成安全配对……")
	}
	out, rc, runErr := runOutputContext(ctx, 20*time.Second, adb, "pair", pairAddr, password)
	if runErr != nil || rc != 0 || outputLooksFailed(out) {
		if errors.Is(runErr, context.Canceled) || errors.Is(runErr, context.DeadlineExceeded) {
			return "", runErr
		}
		if out == "" && runErr != nil {
			out = runErr.Error()
		}
		return "", fmt.Errorf("二维码配对失败：%s", out)
	}

	if onStatus != nil {
		onStatus("配对成功，正在查找无线调试连接地址……")
	}
	for {
		if err := ctx.Err(); err != nil {
			return "", err
		}
		mdnsOut, _, _ := runOutputContext(ctx, 5*time.Second, adb, "mdns", "services")
		for _, rec := range parseMDNSServices(mdnsOut) {
			if rec.Service == "_adb-tls-connect._tcp" && sameAddressHost(rec.Address, pairAddr) {
				return rec.Address, nil
			}
		}
		if err := waitContext(ctx, 900*time.Millisecond); err != nil {
			return "", err
		}
	}
}

func (a *ADBManager) Stop() {
	a.connectMu.Lock()
	a.disconnectLocked(true)
	a.connectMu.Unlock()
	select {
	case <-a.stopWorker:
	default:
		close(a.stopWorker)
	}
	select {
	case <-a.workerDone:
	case <-time.After(2 * time.Second):
	}
}

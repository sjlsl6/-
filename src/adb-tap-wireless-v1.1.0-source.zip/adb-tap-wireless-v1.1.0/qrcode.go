package main

import (
	"bytes"
	"errors"
	"image"
	"image/color"
	"image/png"
	"math"
)

// qrPNG encodes UTF-8 bytes in QR byte mode using error correction level M.
// It intentionally supports versions 1-10, which covers both AirType URLs and
// Android wireless-ADB pairing payloads used by these tools.
func qrPNG(text string, scale int, border int) ([]byte, error) {
	if scale < 1 {
		scale = 8
	}
	if border < 4 {
		border = 4
	}
	matrix, err := makeQR([]byte(text))
	if err != nil {
		return nil, err
	}
	n := len(matrix)
	size := (n + border*2) * scale
	img := image.NewGray(image.Rect(0, 0, size, size))
	white := color.Gray{Y: 255}
	black := color.Gray{Y: 0}
	for y := 0; y < size; y++ {
		for x := 0; x < size; x++ {
			img.SetGray(x, y, white)
		}
	}
	for r, row := range matrix {
		for c, dark := range row {
			if !dark {
				continue
			}
			x0 := (c + border) * scale
			y0 := (r + border) * scale
			for y := y0; y < y0+scale; y++ {
				for x := x0; x < x0+scale; x++ {
					img.SetGray(x, y, black)
				}
			}
		}
	}
	var b bytes.Buffer
	if err := png.Encode(&b, img); err != nil {
		return nil, err
	}
	return b.Bytes(), nil
}

type qrBlock struct{ total, data int }

var qrBlocksM = map[int][]qrBlock{
	1:  {{26, 16}},
	2:  {{44, 28}},
	3:  {{70, 44}},
	4:  {{50, 32}, {50, 32}},
	5:  {{67, 43}, {67, 43}},
	6:  {{43, 27}, {43, 27}, {43, 27}, {43, 27}},
	7:  {{49, 31}, {49, 31}, {49, 31}, {49, 31}},
	8:  {{60, 38}, {60, 38}, {61, 39}, {61, 39}},
	9:  {{58, 36}, {58, 36}, {58, 36}, {59, 37}, {59, 37}},
	10: {{69, 43}, {69, 43}, {69, 43}, {69, 43}, {70, 44}},
}

var qrPatternPos = map[int][]int{
	1: {}, 2: {6, 18}, 3: {6, 22}, 4: {6, 26}, 5: {6, 30}, 6: {6, 34},
	7: {6, 22, 38}, 8: {6, 24, 42}, 9: {6, 26, 46}, 10: {6, 28, 50},
}

var qrExp [512]int
var qrLog [256]int

func init() {
	x := 1
	for i := 0; i < 255; i++ {
		qrExp[i] = x
		qrLog[x] = i
		x <<= 1
		if x&0x100 != 0 {
			x ^= 0x11d
		}
	}
	for i := 255; i < len(qrExp); i++ {
		qrExp[i] = qrExp[i-255]
	}
}

func makeQR(data []byte) ([][]bool, error) {
	version := 0
	for v := 1; v <= 10; v++ {
		capacity := 0
		for _, b := range qrBlocksM[v] {
			capacity += b.data * 8
		}
		countBits := 8
		if v >= 10 {
			countBits = 16
		}
		if 4+countBits+len(data)*8 <= capacity {
			version = v
			break
		}
	}
	if version == 0 {
		return nil, errors.New("二维码内容过长")
	}
	codewords, err := qrCodewords(version, data)
	if err != nil {
		return nil, err
	}
	bestPenalty := math.MaxInt
	var best [][]bool
	for mask := 0; mask < 8; mask++ {
		m := qrBuildMatrix(version, mask, codewords)
		p := qrPenalty(m)
		if p < bestPenalty {
			bestPenalty = p
			best = m
		}
	}
	return best, nil
}

type bitBuffer struct {
	data   []byte
	length int
}

func (b *bitBuffer) put(v uint, n int) {
	for i := n - 1; i >= 0; i-- {
		b.putBit(((v >> i) & 1) != 0)
	}
}
func (b *bitBuffer) putBit(bit bool) {
	idx := b.length / 8
	if idx >= len(b.data) {
		b.data = append(b.data, 0)
	}
	if bit {
		b.data[idx] |= 0x80 >> (b.length % 8)
	}
	b.length++
}

func qrCodewords(version int, payload []byte) ([]byte, error) {
	blocks := qrBlocksM[version]
	totalData := 0
	for _, b := range blocks {
		totalData += b.data
	}
	bb := &bitBuffer{}
	bb.put(4, 4) // byte mode
	countBits := 8
	if version >= 10 {
		countBits = 16
	}
	bb.put(uint(len(payload)), countBits)
	for _, v := range payload {
		bb.put(uint(v), 8)
	}
	bitLimit := totalData * 8
	if bb.length > bitLimit {
		return nil, errors.New("二维码数据溢出")
	}
	for i := 0; i < 4 && bb.length < bitLimit; i++ {
		bb.putBit(false)
	}
	for bb.length%8 != 0 {
		bb.putBit(false)
	}
	pads := []byte{0xec, 0x11}
	for i := 0; len(bb.data) < totalData; i++ {
		bb.data = append(bb.data, pads[i%2])
	}

	dc := make([][]byte, len(blocks))
	ec := make([][]byte, len(blocks))
	off := 0
	maxD, maxE := 0, 0
	for i, bl := range blocks {
		dc[i] = append([]byte(nil), bb.data[off:off+bl.data]...)
		off += bl.data
		eccN := bl.total - bl.data
		ec[i] = qrReedSolomon(dc[i], eccN)
		if len(dc[i]) > maxD {
			maxD = len(dc[i])
		}
		if len(ec[i]) > maxE {
			maxE = len(ec[i])
		}
	}
	out := make([]byte, 0)
	for i := 0; i < maxD; i++ {
		for _, v := range dc {
			if i < len(v) {
				out = append(out, v[i])
			}
		}
	}
	for i := 0; i < maxE; i++ {
		for _, v := range ec {
			if i < len(v) {
				out = append(out, v[i])
			}
		}
	}
	return out, nil
}

func qrReedSolomon(data []byte, degree int) []byte {
	gen := []int{1}
	for i := 0; i < degree; i++ {
		next := make([]int, len(gen)+1)
		for j, g := range gen {
			next[j] ^= g
			next[j+1] ^= qrMul(g, qrExp[i])
		}
		gen = next
	}
	rem := make([]int, degree)
	for _, b := range data {
		factor := int(b) ^ rem[0]
		copy(rem, rem[1:])
		rem[degree-1] = 0
		if factor != 0 {
			for j := 0; j < degree; j++ {
				rem[j] ^= qrMul(gen[j+1], factor)
			}
		}
	}
	out := make([]byte, degree)
	for i, v := range rem {
		out[i] = byte(v)
	}
	return out
}
func qrMul(a, b int) int {
	if a == 0 || b == 0 {
		return 0
	}
	return qrExp[qrLog[a]+qrLog[b]]
}

func qrBuildMatrix(version, mask int, data []byte) [][]bool {
	n := version*4 + 17
	m := make([][]bool, n)
	set := make([][]bool, n)
	for i := 0; i < n; i++ {
		m[i] = make([]bool, n)
		set[i] = make([]bool, n)
	}
	put := func(r, c int, v bool) {
		if r >= 0 && r < n && c >= 0 && c < n {
			m[r][c] = v
			set[r][c] = true
		}
	}
	finder := func(row, col int) {
		for r := -1; r <= 7; r++ {
			for c := -1; c <= 7; c++ {
				if row+r < 0 || row+r >= n || col+c < 0 || col+c >= n {
					continue
				}
				dark := (r >= 0 && r <= 6 && (c == 0 || c == 6)) || (c >= 0 && c <= 6 && (r == 0 || r == 6)) || (r >= 2 && r <= 4 && c >= 2 && c <= 4)
				put(row+r, col+c, dark)
			}
		}
	}
	finder(0, 0)
	finder(n-7, 0)
	finder(0, n-7)
	// alignment patterns
	pos := qrPatternPos[version]
	for _, row := range pos {
		for _, col := range pos {
			if set[row][col] {
				continue
			}
			for r := -2; r <= 2; r++ {
				for c := -2; c <= 2; c++ {
					put(row+r, col+c, abs(r) == 2 || abs(c) == 2 || (r == 0 && c == 0))
				}
			}
		}
	}
	// timing
	for i := 8; i < n-8; i++ {
		if !set[i][6] {
			put(i, 6, i%2 == 0)
		}
		if !set[6][i] {
			put(6, i, i%2 == 0)
		}
	}
	// reserve/write format info (ECC M = 0)
	typeInfo := qrBCHTypeInfo(mask)
	for i := 0; i < 15; i++ {
		bit := ((typeInfo >> i) & 1) != 0
		var r int
		if i < 6 {
			r = i
		} else if i < 8 {
			r = i + 1
		} else {
			r = n - 15 + i
		}
		put(r, 8, bit)
		var c int
		if i < 8 {
			c = n - i - 1
		} else if i < 9 {
			c = 15 - i
		} else {
			c = 15 - i - 1
		}
		put(8, c, bit)
	}
	put(n-8, 8, true)
	if version >= 7 {
		bits := qrBCHTypeNumber(version)
		for i := 0; i < 18; i++ {
			bit := ((bits >> i) & 1) != 0
			put(i/3+i%3+n-8-1, i%3, bit)
			put(i%3, i/3+i%3+n-8-1, bit)
		}
	}
	// map data, two columns at a time, upwards/downwards
	bitIndex := 0
	row := n - 1
	inc := -1
	for col := n - 1; col > 0; col -= 2 {
		if col == 6 {
			col--
		}
		for {
			for c := 0; c < 2; c++ {
				cc := col - c
				if !set[row][cc] {
					dark := false
					if bitIndex < len(data)*8 {
						dark = ((data[bitIndex/8] >> (7 - (bitIndex % 8))) & 1) != 0
						bitIndex++
					}
					if qrMask(mask, row, cc) {
						dark = !dark
					}
					m[row][cc] = dark
					set[row][cc] = true
				}
			}
			row += inc
			if row < 0 || row >= n {
				row -= inc
				inc = -inc
				break
			}
		}
	}
	return m
}

func qrBCHTypeInfo(data int) int {
	d := data << 10
	const g = 0x537
	for qrBitLen(d)-qrBitLen(g) >= 0 {
		d ^= g << (qrBitLen(d) - qrBitLen(g))
	}
	return ((data << 10) | d) ^ 0x5412
}
func qrBCHTypeNumber(data int) int {
	d := data << 12
	const g = 0x1f25
	for qrBitLen(d)-qrBitLen(g) >= 0 {
		d ^= g << (qrBitLen(d) - qrBitLen(g))
	}
	return (data << 12) | d
}
func qrBitLen(v int) int {
	n := 0
	for v != 0 {
		n++
		v >>= 1
	}
	return n
}
func qrMask(p, r, c int) bool {
	switch p {
	case 0:
		return (r+c)%2 == 0
	case 1:
		return r%2 == 0
	case 2:
		return c%3 == 0
	case 3:
		return (r+c)%3 == 0
	case 4:
		return (r/2+c/3)%2 == 0
	case 5:
		return r*c%2+r*c%3 == 0
	case 6:
		return (r*c%2+r*c%3)%2 == 0
	default:
		return ((r*c)%3+(r+c)%2)%2 == 0
	}
}
func abs(v int) int {
	if v < 0 {
		return -v
	}
	return v
}

func qrPenalty(m [][]bool) int {
	n := len(m)
	score := 0
	// runs
	for r := 0; r < n; r++ {
		run := 1
		for c := 1; c < n; c++ {
			if m[r][c] == m[r][c-1] {
				run++
			} else {
				if run >= 5 {
					score += 3 + run - 5
				}
				run = 1
			}
		}
		if run >= 5 {
			score += 3 + run - 5
		}
	}
	for c := 0; c < n; c++ {
		run := 1
		for r := 1; r < n; r++ {
			if m[r][c] == m[r-1][c] {
				run++
			} else {
				if run >= 5 {
					score += 3 + run - 5
				}
				run = 1
			}
		}
		if run >= 5 {
			score += 3 + run - 5
		}
	}
	// 2x2 blocks
	for r := 0; r < n-1; r++ {
		for c := 0; c < n-1; c++ {
			v := m[r][c]
			if m[r+1][c] == v && m[r][c+1] == v && m[r+1][c+1] == v {
				score += 3
			}
		}
	}
	// finder-like patterns with four light modules before or after
	pattern := []bool{true, false, true, true, true, false, true}
	for r := 0; r < n; r++ {
		for c := 0; c <= n-7; c++ {
			if qrMatchRow(m, r, c, pattern) && (qrLightRow(m, r, c-4, c) || qrLightRow(m, r, c+7, c+11)) {
				score += 40
			}
		}
	}
	for c := 0; c < n; c++ {
		for r := 0; r <= n-7; r++ {
			if qrMatchCol(m, c, r, pattern) && (qrLightCol(m, c, r-4, r) || qrLightCol(m, c, r+7, r+11)) {
				score += 40
			}
		}
	}
	dark := 0
	for _, row := range m {
		for _, v := range row {
			if v {
				dark++
			}
		}
	}
	percent := float64(dark) * 100 / float64(n*n)
	score += int(math.Abs(percent-50)/5) * 10
	return score
}
func qrMatchRow(m [][]bool, r, c int, p []bool) bool {
	for i, v := range p {
		if m[r][c+i] != v {
			return false
		}
	}
	return true
}
func qrMatchCol(m [][]bool, c, r int, p []bool) bool {
	for i, v := range p {
		if m[r+i][c] != v {
			return false
		}
	}
	return true
}
func qrLightRow(m [][]bool, r, a, b int) bool {
	if a < 0 || b > len(m) {
		return false
	}
	for c := a; c < b; c++ {
		if m[r][c] {
			return false
		}
	}
	return true
}
func qrLightCol(m [][]bool, c, a, b int) bool {
	if a < 0 || b > len(m) {
		return false
	}
	for r := a; r < b; r++ {
		if m[r][c] {
			return false
		}
	}
	return true
}

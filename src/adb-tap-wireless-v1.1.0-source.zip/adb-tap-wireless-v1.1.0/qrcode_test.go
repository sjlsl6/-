package main

import (
	"bytes"
	"testing"
)

func TestQRCodePNG(t *testing.T) {
	payload := "WIFI:T:ADB;S:studio-AbCd234567;P:ABCDEFGH2345;;"
	pngData, err := qrPNG(payload, 6, 4)
	if err != nil {
		t.Fatal(err)
	}
	if len(pngData) < 100 || !bytes.HasPrefix(pngData, []byte{0x89, 'P', 'N', 'G'}) {
		t.Fatal("invalid PNG")
	}
}

package main

import (
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	"sync"
	"time"
)

type PairingState struct {
	ID        string    `json:"id"`
	Active    bool      `json:"active"`
	Status    string    `json:"status"`
	Error     string    `json:"error"`
	Address   string    `json:"address"`
	ExpiresAt time.Time `json:"expiresAt"`
}

type PairingManager struct {
	// lifecycleMu serializes session replacement/cancellation with the final
	// save-and-connect commit, so an older QR session can never overwrite a
	// newer session or reconnect after it has been cancelled.
	lifecycleMu sync.Mutex
	mu          sync.RWMutex
	adb         *ADBManager
	config      *ConfigStore
	status      *StatusStore
	state       PairingState
	payload     string
	cancel      context.CancelFunc
}

func newPairingManager(adb *ADBManager, config *ConfigStore, status *StatusStore) *PairingManager {
	return &PairingManager{adb: adb, config: config, status: status}
}

const pairAlphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"

func randomPairText(n int) (string, error) {
	if n <= 0 {
		return "", nil
	}
	raw := make([]byte, n)
	if _, err := rand.Read(raw); err != nil {
		return "", err
	}
	out := make([]byte, n)
	for i, b := range raw {
		out[i] = pairAlphabet[int(b)%len(pairAlphabet)]
	}
	return string(out), nil
}

func (p *PairingManager) Start() (PairingState, error) {
	p.lifecycleMu.Lock()
	defer p.lifecycleMu.Unlock()

	if !p.adb.ADBAvailable() {
		return PairingState{}, errors.New("未找到可用的 ADB，请先点击“一次性准备 ADB”")
	}
	id, err := randomPairText(16)
	if err != nil {
		return PairingState{}, fmt.Errorf("生成配对会话失败：%w", err)
	}
	suffix, err := randomPairText(10)
	if err != nil {
		return PairingState{}, fmt.Errorf("生成配对名称失败：%w", err)
	}
	password, err := randomPairText(12)
	if err != nil {
		return PairingState{}, fmt.Errorf("生成配对密码失败：%w", err)
	}
	service := "studio-" + suffix
	payload := fmt.Sprintf("WIFI:T:ADB;S:%s;P:%s;;", service, password)
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)

	p.mu.Lock()
	if p.cancel != nil {
		p.cancel()
	}
	p.cancel = cancel
	p.payload = payload
	p.state = PairingState{ID: id, Active: true, Status: "二维码已生成，请在手机无线调试中扫描", ExpiresAt: time.Now().Add(2 * time.Minute)}
	state := p.state
	p.mu.Unlock()
	p.status.Action("ADB 二维码配对已启动；仅在本次会话中临时发现设备")

	go p.run(ctx, id, service, password)
	return state, nil
}

func (p *PairingManager) run(ctx context.Context, id, service, password string) {
	address, err := p.adb.PairByQRCode(ctx, service, password, func(text string) { p.updateStatus(id, text) })

	// Start and Cancel take the same lifecycle lock. Once this session reaches
	// the commit stage, no newer session can replace it halfway through saving
	// the address or opening the persistent shell. Conversely, if it was already
	// replaced while discovery was running, it exits without side effects.
	p.lifecycleMu.Lock()
	defer p.lifecycleMu.Unlock()

	p.mu.RLock()
	current := p.state.ID == id && p.state.Active
	p.mu.RUnlock()
	if !current {
		return
	}
	if err == nil {
		if ctxErr := ctx.Err(); ctxErr != nil {
			err = ctxErr
		} else if _, saveErr := p.config.SetAddress(address); saveErr != nil {
			err = fmt.Errorf("配对成功但保存连接地址失败：%w", saveErr)
		} else if _, connectErr := p.adb.Connect(address); connectErr != nil {
			err = fmt.Errorf("配对成功但建立点击通道失败：%w", connectErr)
		}
	}

	p.mu.Lock()
	defer p.mu.Unlock()
	if p.state.ID != id {
		return
	}
	p.state.Active = false
	p.cancel = nil
	if err == nil {
		p.state.Status = "二维码配对并连接成功"
		p.state.Error = ""
		p.state.Address = address
		p.status.Action("二维码配对并连接成功；小键盘 - 和 + 已就绪")
		return
	}
	if errors.Is(err, context.Canceled) {
		p.state.Status = "二维码配对已取消"
		p.state.Error = ""
		return
	}
	if errors.Is(err, context.DeadlineExceeded) {
		p.state.Status = "二维码已过期"
		p.state.Error = "两分钟内未完成配对，请重新生成二维码"
		p.status.Error(p.state.Error)
		return
	}
	p.state.Status = "二维码配对失败"
	p.state.Error = err.Error()
	p.status.Error(err.Error())
}

func (p *PairingManager) updateStatus(id, text string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.state.ID == id && p.state.Active {
		p.state.Status = text
	}
}

func (p *PairingManager) State() PairingState {
	p.mu.RLock()
	defer p.mu.RUnlock()
	return p.state
}

func (p *PairingManager) QRPayload(id string) (string, bool) {
	p.mu.RLock()
	defer p.mu.RUnlock()
	if id == "" || id != p.state.ID || p.payload == "" {
		return "", false
	}
	return p.payload, true
}

func (p *PairingManager) Cancel() {
	p.lifecycleMu.Lock()
	defer p.lifecycleMu.Unlock()

	p.mu.Lock()
	cancel := p.cancel
	if p.state.Active {
		p.state = PairingState{Status: "二维码配对已取消"}
		p.payload = ""
	}
	p.cancel = nil
	p.mu.Unlock()
	if cancel != nil {
		cancel()
	}
}
